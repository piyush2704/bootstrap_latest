import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'canect-grid',
    templateUrl: './grid.component.html',
    styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {
    private gridData: any[] = [{
        "AssetID": 1,
        "AssetName": "Asset1",
        "Status": 1,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 2,
        "AssetName": "Asset2",
        "Status": 1,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 3,
        "AssetName": "Asset3",
        "Status": 1,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 4,
        "AssetName": "Asset4",
        "Status": 2,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 5,
        "AssetName": "Asset5",
        "Status": 2,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 6,
        "AssetName": "Asset6",
        "Status": 3,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 7,
        "AssetName": "Asset7",
        "Status": 3,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 8,
        "AssetName": "Asset8",
        "Status": 3,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 9,
        "AssetName": "Asset9",
        "Status": 4,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }, {
        "AssetID": 10,
        "AssetName": "Asset10",
        "Status": 4,
        "Location": "Co-ordinates",
        "AlertNotification": "1"
    }
    ];

    constructor() { }

    ngOnInit() {
    }

}
