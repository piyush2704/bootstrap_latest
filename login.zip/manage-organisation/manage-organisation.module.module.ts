import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
// import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import {ManageOrganisationComponent} from './manage.organisation.component';
import {ManageOrganisationService} from './manage.organisation.service';
import { fakeBackendProvider } from './../login/login/fake.backend';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions } from '@angular/http';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from '../app/dashboard/dashboard.component';
import { DashboardModule } from '../app/dashboard/dashboard.module';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    DropDownsModule,
    GridModule,
    ReactiveFormsModule,
    ButtonsModule,
    InputsModule,
    RouterModule
  ],
  exports: [ManageOrganisationComponent],
  declarations: [
    ManageOrganisationComponent
  ],
  providers: [ManageOrganisationService,fakeBackendProvider, MockBackend, BaseRequestOptions],
})
export class LoginModule { }
