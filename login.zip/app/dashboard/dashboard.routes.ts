import { Routes } from "@angular/router";
import { DashboardComponent } from "./dashboard.component";
import {ManageOrganisationComponent} from './manage-organisation/manage.organisation.component';
import { MapComponent } from "./../../shared/modules/map/map.component";
import { AuthGuard } from "./../../login/login/authgaurd";

export const dashboardRoutes: Routes = [
    // {
    //     path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard], canActivateChild: [AuthGuard], children: [
    //         { path: '', redirectTo: 'maps', pathMatch: 'full' },
    //         { path: 'maps', component: MapComponent },
    //     ]
    // }
    { path: 'maps', component: MapComponent },
    { path: 'dashboard', component: DashboardComponent ,
children: [
      {
        path: 'manageorganisation',
        component: ManageOrganisationComponent
      }]
}

];