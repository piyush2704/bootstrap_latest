import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { DashboardComponent } from './dashboard.component';
import { RouterModule } from "@angular/router";
import { dashboardRoutes } from "./dashboard.routes";
import { MapComponent } from "./../../shared/modules/index";
import { AuthGuard } from "./../../login/login/authgaurd";
import {ManageOrganisationComponent} from './manage-organisation/manage.organisation.component';
import {ManageOrganisationService} from './manage-organisation/manage.organisation.service';
import { HeaderComponent, SidebarComponent, FooterComponent, FilterComponent, GridComponent } from './../../shared/modules/index';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Kendo - Modules
import { LayoutModule } from '@progress/kendo-angular-layout';
import { DropDownsModule, DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IntlModule } from '@progress/kendo-angular-intl';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';

// PrimeNG - Modules
import { MultiSelectModule } from 'primeng/primeng';

@NgModule({
    imports: [
        FormsModule,
        HttpModule,
        ReactiveFormsModule,
        CommonModule,
        RouterModule.forChild(dashboardRoutes),
        LayoutModule, DropDownsModule, DropDownListModule, GridModule,
        MultiSelectModule, ButtonsModule, IntlModule, DateInputsModule
    ],
    declarations: [DashboardComponent, HeaderComponent, SidebarComponent, FooterComponent, MapComponent, FilterComponent, GridComponent,
    ManageOrganisationComponent],
    exports: [DashboardComponent],
    providers: [AuthGuard,ManageOrganisationService]
})
export class DashboardModule {
}
