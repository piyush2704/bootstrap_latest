 export const Organisation = [{
    'id':1,
    'themeUrl': 'https://www.telerik.com/kendo-angular-ui/npm/node_modules//@progress/kendo-theme-bootstrap/dist/all.css',
    'logourl':'./assets/img/favicon.png',
    'orgaisationname':'Company1',
    'bgurl':'http://www.hedonline.com/HED-Files/Markets/Fire.jpg?'
 },
{
    'id':2,
    'themeUrl': 'https://www.telerik.com/kendo-angular-ui/npm/node_modules//@progress/kendo-theme-default/dist/all.css',
    'logourl':'./assets/img/logo.png',
    'orgaisationname':'Company2',
    'bgurl':'http://www.hedonline.com/HED-Files/Markets/Ag-Market-Page.jpg'
 },
{
    'id':3,
    'themeUrl': 'https://www.telerik.com/kendo-angular-ui/npm/node_modules//@progress/kendo-theme-default/dist/all.css',
    'logourl':'./assets/img/logo.png',
    'orgaisationname':'Company3',
    'bgurl':''
 },]