import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {Login} from './components/app-login/app.login.component';
import {RegisterComponent} from  './components/app-register/app.register.component';
export const routes: Routes = [
   {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'login',
    component: Login,
    data: {
      title: 'Login'
    },
  },
     {
    path: 'register',
    component: RegisterComponent,
    data: {
      title: 'Login'
    }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
