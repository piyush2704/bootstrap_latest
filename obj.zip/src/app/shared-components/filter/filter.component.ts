import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
 public listItems: Array<string> = ['Baseball', 'Basketball', 'Cricket',
 'Field Hockey', 'Football', 'Table Tennis', 'Tennis', 'Volleyball'];
    public organisation: any ;
    public fleet: any ;
    public asset: any;
  constructor() { }

  ngOnInit() {
  }

}
