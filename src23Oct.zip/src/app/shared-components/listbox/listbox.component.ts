import { Component, OnInit, Input, Output,EventEmitter ,ViewChild } from '@angular/core';

@Component({
  selector: 'app-listbox-filter',
  templateUrl: './listbox.component.html',
  styleUrls: ['./listbox.component.css']
})
export class ListBoxComponent implements OnInit {
    @Input () getTableData;
    @Input () getTableHeaders;
    @Output () SelectedResults;
  constructor() {
   }
      ngOnInit() {
  }

}
