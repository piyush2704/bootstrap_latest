import { Component, OnInit, Input, Output,EventEmitter ,ViewChild } from '@angular/core';

@Component({
  selector: 'app-wizard-filter',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.css']
})
export class WizardComponent implements OnInit {
    @Input () showwizard:boolean ;
  constructor() {
   }
      ngOnInit() {
  }

}
