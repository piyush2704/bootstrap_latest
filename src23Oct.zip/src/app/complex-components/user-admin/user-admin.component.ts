import { Component, OnInit } from '@angular/core';
import { products  } from './const';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import {Hero} from './hero'

@Component({
  selector: 'app-user-admin',
  templateUrl: './user-admin.component.html',
  styleUrls: ['./user-admin.component.css']
})

export class UserAdminComponent implements OnInit {
  public multiple: boolean = false;
    public allowUnsort: boolean = true;
    public step = 'step2';
     powers = ["Really Smart", "Super Flexible", "Weather Changer"];

  hero = new Hero(18, "Dr. WhatIsHisName", this.powers[0], "Dr. What");

  submitted = false;
    private showwiard:boolean = false;
    wizardForm: FormGroup;
    public Headers = [
      {
        'step':'1',
        'title':'Basic Details',
        'selected':true
      },
      {
        'step':'2',
        'title':'Attach User Roles',
        'selected':false
      },
      {
        'step':'1',
        'title':'Attach Fleet',
        'selected':false
      },
    ]
    private sort: SortDescriptor[] = [];
    private gridView: GridDataResult;
    private products: any[] = products ;

    protected sortChange(sort: SortDescriptor[]): void {
        this.sort = sort;
        this.loadProducts();
    }

    private loadProducts(): void {
        this.gridView = {
            data: orderBy(this.products, this.sort),
            total: this.products.length
        };
    }
      addWizard(event) {
        this.showwiard = true;
      }
  getFilterCriteria(event){
    console.log(event);
    if(event = 'addeventClicked') {
    this.showwiard = true;
    }
  }  constructor(private fb: FormBuilder) {
    this.loadProducts();
    
   }  ngOnInit() {
      this.buildForm(); 
  }
onSubmit() {
    this.submitted = true;
    this.hero = this.wizardForm.value;
  }
   
  addHero() {
    this.hero = new Hero(42, "", "");
    this.buildForm();
  }
   buildForm(): void {
    this.wizardForm = this.fb.group({
      "firstName": ["",[
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(24),
      ]],
    "middleName": ["",[
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(24),
      ]],
    "lastName": ["",[
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(24),
      ]],
      "location": ["",Validators.required,],
      "accounttype": ["", Validators.required],
      "date": ["", Validators.required],
      "username": ["", Validators.required],
      "password": ["", Validators.required],
      "retypepassword": ["", Validators.required],
      "email": ["", Validators.required],
      "mobile": ["", Validators.required],
    });

    this.wizardForm.valueChanges
      .subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set validation messages now
  }
   onValueChanged(data?: any) {
    if(!this.wizardForm) { return; }
    
  }
  cancel() {
    this.reset();
    this.showwiard=false;
  }
reset() {
  this.wizardForm.reset();
}
  formErrors = {};
}
