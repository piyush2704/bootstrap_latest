import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserAdminComponent } from './complex-components/user-admin/user-admin.component';
export const routes: Routes = [
 {
    path: '',
    redirectTo: 'userAdmin',
    pathMatch: 'full',
  },
  {
    path: 'userAdmin',
    component: UserAdminComponent,
    data: {
      title: 'User Admin'
    }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
