import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {ReactiveFormsModule } from '@angular/forms';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { AuthenticationService } from './components/app-login/app.login.service';
import {Login} from  './components/app-login/app.login.component';
import {RegisterComponent} from  './components/app-register/app.register.component';
import {ForgotPassword} from  './components/app-forgot-password/app.forgotpassword.component';
import {ManageOrganisationComponent} from  './components/manage-organisation/manage.organisation.component';
import {ManageOrganisationService} from  './components/manage-organisation/manage.organisation.service';
import {fakeBackendProvider} from  './components/app-login/fake.backend';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions } from '@angular/http';
@NgModule({
  declarations: [
    AppComponent,
    Login,
    RegisterComponent,
    ForgotPassword,
    ManageOrganisationComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    DropDownsModule,
    GridModule,
    AppRoutingModule,
    ReactiveFormsModule,
    ButtonsModule,
    InputsModule
  ],
  providers: [ AuthenticationService,fakeBackendProvider,MockBackend,BaseRequestOptions,ManageOrganisationService
    ],
  bootstrap: [AppComponent]
})
export class AppModule { }
