import { Component, Inject,ViewEncapsulation  } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  sub;
  constructor(@Inject(DOCUMENT) private document,private activeRoute:ActivatedRoute) {

  }
  ngOnInit() {
    this.sub = this.activeRoute.queryParams.subscribe(params => {
      let id = params['companyid'];
     console.log(id);
     let org = JSON.parse(sessionStorage.getItem('currentOrganisation'));
                  this.document.getElementById('theme').setAttribute
                   ('href', org['themeUrl']);
                   let bgurl =  'background-image: url' + '(' + org.bgurl + ')';
                   this.document.getElementById('body').setAttribute("style", bgurl);
   });
  }
}
