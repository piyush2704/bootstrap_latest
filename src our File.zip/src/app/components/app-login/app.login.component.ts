import { Component, Inject,ViewEncapsulation  } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
import { AuthenticationService } from './app.login.service';
import { User } from './users';
import { Title } from '@angular/platform-browser';
@Component({
  selector: 'app-login',
  templateUrl: './app.login.component.html',
  encapsulation:ViewEncapsulation.None
})
export class Login {
    constructor(private title:Title,private _route:Router,@Inject(DOCUMENT) private document,private activeRoute:ActivatedRoute,private _authenticationService: AuthenticationService) {

    }
  model: any = {};
    url;        // this is for image logo
    sub ;      //this is for extract the id from the url
    currentUser: User;
    users: User[] = [];
    loading = false;
    registerOutlet;
    returnUrl: string;
  login() {
        this.loading = true;
        if (this.model.rememberme === true)
            {
                localStorage.setItem('saveUsername',this.model.username);
            }
        this._authenticationService.login(this.model.username, this.model.password)
            .subscribe(
                data => {
                  //  alert('login');
                  this.title.setTitle('logout');
                    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
                },
                error => {
                    alert(error);
                                   });
    }
  ngOnInit() {
     this.title.setTitle('login');
     this._authenticationService.logout();
     this.currentUser = null;
     this.model = {};
     this.model.username = localStorage.getItem('saveUsername');
     this.sub = this.activeRoute.queryParams.subscribe(params => {
      let id = params['companyid'];
      if(id) {
        this.registerOutlet = {'companyid': id} ;
      }
         console.log(id);
         this._authenticationService.getTheme(id)
            .subscribe(
                data => {
                  //  alert('login');
                  let org = JSON.parse(sessionStorage.getItem('currentOrganisation'));
                  this.url = org['logourl'];
                  this.document.getElementById('theme').setAttribute
                   ('href', org['themeUrl']);
                   let bgurl =  'background-image: url' + '(' + org.bgurl + ')';
                   this.document.getElementById('body').setAttribute("style", bgurl);
                },
                error => {
                    console.log('theme not available');
                                   });
   });
    }

}