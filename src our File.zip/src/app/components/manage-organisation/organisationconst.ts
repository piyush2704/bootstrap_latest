export const Organisation = [
        {
            'id':'1042',
            'name':'Organization 1',
            'nou':'10',
            'noa':'20',
            'nof':'40',
            'nous':'10',
            'nos':'12',
            'noas':'10',
            'nom':'11',
            'subOrganisation':[{
                    'id':'1082',
                    'name':'Sub Organization 1',
            },
            {
                    'id':'1032',
                    'name':'Sub Organization 2',
            },
            {
                    'id':'1087',
                    'name':' Sub Organization 3',
            },
            {
                    'id':'1092',
                    'name':'Sub Organization 4',
            }]
    
        },
        {
            'id':'1088',
            'name':'Abcdefgh',
            'nou':'2',
            'noa':'3',
            'nous':'11',
            'noas':'23',
            'nom':'22',
            'subOrganisation':[{
                    'id':'1111',
                    'name':'Xyz',
                    
            'subOrganisation':[{
                    'id':'1',
                    'name':'efg 1',
            },
            {
                    'id':'32',
                    'name':'efg 2',
            },
            {
                    'id':'87',
                    'name':' efg 3',
            },
            {
                    'id':'92',
                    'name':'efg 4',
            }]
            }
            ]
        },
        {
            'id':'1099',
            'name':'CANect',
            'nou':'10',
            'noa':'17',
            'nof':'70',
            'noas':'21',
            'nom':'22',
            'subOrganisation':[{
                    'id':'1043',
                    'name':'Sub CANect 1',
            },
            {
                    'id':'1035',
                    'name':'Sub CANect 2',
            },
        {
                    'id':'1065',
                    'name':'Sub CANect 3',
            }]
        },
        {
            'id':'1076',
            'name':'Org 12',
            'nou':'21',
            'noa':'22',
            'noas':'22',
            'nom':'12',
        },
    ]