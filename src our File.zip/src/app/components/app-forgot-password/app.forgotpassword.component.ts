import { Component } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';

import {AuthenticationService } from '../app-login/app.login.service';

@Component({
    moduleId: module.id,
    templateUrl: 'app.forgotpassword.component.html'
})

export class ForgotPassword {
    model: any = {};
    loading = false;
    sub;
    registerOutlet;
    constructor(
        private router: Router,
        private userService: AuthenticationService,
        private activeRoute:ActivatedRoute
) { }

    confirmClick() {
        this.loading = true;
        this.userService.create(this.model)
            .subscribe(
                data => {
                    console.log('registration suggessful');
                    this.router.navigate(['/login'],{queryParams:this.registerOutlet});
                },
                error => {
                    alert('registration failed');
                    console.log('registration failed');
                    this.loading = false;
                });
    }
    ngOnInit() {
      this.sub = this.activeRoute.queryParams.subscribe(params => {
      let id = params['companyid'];
      if(id) {
      this.registerOutlet = {'companyid': id} ;
      }
     });
   }  
}
