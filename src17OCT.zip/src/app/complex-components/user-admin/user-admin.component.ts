import { Component, OnInit } from '@angular/core';
import { products  } from './const';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';

@Component({
  selector: 'app-user-admin',
  templateUrl: './user-admin.component.html',
  styleUrls: ['./user-admin.component.css']
})

export class UserAdminComponent implements OnInit {
  public multiple: boolean = false;
    public allowUnsort: boolean = true;

    private sort: SortDescriptor[] = [];
    private gridView: GridDataResult;
    private products: any[] = products ;

    protected sortChange(sort: SortDescriptor[]): void {
        this.sort = sort;
        this.loadProducts();
    }

    private loadProducts(): void {
        this.gridView = {
            data: orderBy(this.products, this.sort),
            total: this.products.length
        };
    }
  getFilterCriteria(event){
    console.log(event);
  }  constructor() {
    this.loadProducts();
   }  ngOnInit() {
  }

}
