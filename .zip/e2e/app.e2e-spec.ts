import { CANectPortalPage } from './app.po';

describe('canect-portal App', () => {
  let page: CANectPortalPage;

  beforeEach(() => {
    page = new CANectPortalPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
