import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { GridComponent, GridDataResult, DataStateChangeEvent } from '@progress/kendo-angular-grid';

import { SortDescriptor,orderBy } from '@progress/kendo-data-query';
import { fleetList } from './fleetlist';


@Component({
    selector: 'canect-grid',
    templateUrl: './grid.component.html',
    styleUrls: ['./grid.component.css']
})
export class CanectGridComponent implements OnInit {
    public gridView: GridDataResult;
    public view: Observable<GridDataResult>;
    public sort: SortDescriptor[] = [];
    public pageSize: number = 10;
    public skip: number = 0;
    
    @ViewChild(GridComponent) grid: GridComponent;
    private assets: any[] = [];

    constructor() { 
        this.loadData();
    }

    ngOnInit() {
        
    }

    public sortChange(sort: SortDescriptor[]): void {
        this.sort = sort;
        this.loadData();
    }


    private loadData(): void {
        this.assets = fleetList;
        this.gridView = {
            data: orderBy(this.assets, this.sort),
            total: this.assets.length
        };
    }
}

// export class CanectGridComponent {
//     private gridView: any[] = fleetList;
//     make = fleetList;
// }
