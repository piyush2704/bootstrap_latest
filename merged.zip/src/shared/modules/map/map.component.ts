import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

    displayLeft() {
      document.getElementById("left-filter").hidden = true;
      document.getElementById("right-filter").hidden = false;
      document.getElementById("mapid").style.width = "100%";
      document.getElementById("right-filter").style.width = "100%";
      document.getElementById("mapid").style.marginLeft = "0px";
    }
  
    displayRight() {
      document.getElementById("left-filter").removeAttribute("style");
      document.getElementById("mapid").removeAttribute("style");
      document.getElementById("left-filter").hidden = false;
      document.getElementById("right-filter").hidden = true;
    }

  

}
