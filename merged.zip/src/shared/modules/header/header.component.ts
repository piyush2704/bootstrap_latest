import { Component, AfterViewInit, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
@Component({
  selector: 'canect-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  number = '3';
  logoPath: string;
  constructor(private _Router :Router) { }

  ngOnInit() {
    this.logoPath = "/assets/images/HED_Logo.png";
  }

  ngAfterViewInit() {

    $('[data-toggle="offcanvas"]').click(function () {
      $('#wrapper').toggleClass('toggled');
    });

    $('#search-button').on('click', function (e) {
      if ($('#search-input-container').hasClass('hdn')) {
        e.preventDefault();
        $('#search-input-container').removeClass('hdn')
        return false;
      }
    });

    $('#hide-search-input-container').on('click', function (e) {
      e.preventDefault();
      $('#search-input-container').addClass('hdn')
      return false;
    });

  }
logout() {
  let currentorg = JSON.parse(sessionStorage.getItem('currentcompany'));
  if(currentorg) {
  this._Router.navigate(['/login'],{ queryParams: {'companyid':currentorg}}) ;
  } else {
  }
this._Router.navigate(['/login']);
}
}
