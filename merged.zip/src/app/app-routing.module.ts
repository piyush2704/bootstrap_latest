import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginModule } from './../login/login.module';
import { Login, RegisterComponent,ForgotPassword } from '../login/index';
import { MapComponent } from '../shared/modules/index';
import { PageNotFoundComponent } from './../page-not-found/page-not-found.component';

export const APP_ROUTES: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login, data: { title: 'Login' } },
  { path: 'register', component: RegisterComponent },
  {path: 'forgotpassword', component: ForgotPassword},
  { path: '**', component: PageNotFoundComponent },
  // {path: '', redirectTo: 'dashboard', pathMatch: 'full'},
];
