import { Component, AfterViewInit, Inject , OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router,ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
sub;
  constructor(@Inject(DOCUMENT) private document,private activeRoute:ActivatedRoute) { }

 
  ngOnInit() {
    this.sub = this.activeRoute.queryParams.subscribe(params => {
      let id = params['companyid'];
     console.log(id);
     if(id) {
     let org = JSON.parse(sessionStorage.getItem('currentOrganisation'));
                  if(org) { 
                    if(org.themeUrl) {
                  this.document.getElementById('theme').setAttribute
                   ('href', org['themeUrl']);
                    }
                  if(org.bgurl) {
                   let bgurl =  'background-image: url' + '(' + org.bgurl + ')';
                   this.document.getElementById('body').setAttribute("style", bgurl);
                  }
                  }
    }
   });
    $(document).ready(function () {
      $('[data-toggle="offcanvas"]').click(function () {
        $('#wrapper').toggleClass('toggled');
      });
    });
  }

  ngAfterViewInit() {

    var trigger = $('.hamburger'),
      overlay = $('.overlay'),
      isClosed = true;
    trigger.addClass("is-open");
    trigger.click(function () {
      hamburger_cross();
    });

    function hamburger_cross() {
      if (isClosed == true) {
        overlay.hide();
        trigger.removeClass('is-open');
        trigger.addClass('is-closed');
        isClosed = !isClosed;
      } else {
        overlay.show();
        trigger.removeClass('is-closed');
        trigger.addClass('is-open');
        isClosed = !isClosed;
      }
    }

    $('[data-toggle="offcanvas"]').click(function () {
      $('#wrapper').toggleClass('toggled');
    });

    $('#search-button').on('click', function (e) {
      if ($('#search-input-container').hasClass('hdn')) {
        e.preventDefault();
        $('#search-input-container').removeClass('hdn')
        return false;
      }
    });

    $('#hide-search-input-container').on('click', function (e) {
      e.preventDefault();
      $('#search-input-container').addClass('hdn')
      return false;
    });

  }

}
