export const Organisation = [
        {
            'id':'1042',
            'name':'Organization 1',
            'nou':'10',
            'noa':'20',
            'nof':'40',
            'nous':'10',
            'nos':'12',
            'noas':'10',
            'nom':'11',
            'logo':'fa fa-user',
            'subOrganization':[{
                    'id':'1082',
                    'name':'Sub Organization 1',
                    'nou':'-',
                    'noa':'100',
                    'nof':'1',
                    'nous':'-',
                    'logo':'fa fa-cc-diners-club'
            },
            {
                    'id':'1032',
                    'name':'Sub Organization 2',
                    'nou':'10',
                    'noa':'20',
                    'nof':'40',
                    'nous':'10',
                    'nos':'12',
                    'noas':'10',
                    'nom':'11',
                    'logo':'fa fa-first-order'
            },
            {
                    'id':'1087',
                    'name':' Sub Organization 3',
                    'nou':'-',
                    'noa':'100',
                    'nof':'1',
                    'nous':'-',
                    'nos':'-',
                    'noas':'20',
                    'nom':'-',
                    
                    
            },
            {
                    'id':'1092',
                    'name':'Sub Organization 4',
                    'nou':'10',
                    'noa':'20',
                    'nof':'40',
                    'nous':'10',
                    'nos':'12',
                    'noas':'10',
                    'nom':'11',
                    'logo':'fa fa-forumbee'
            }]
    
        },
        {
            'id':'1088',
            'name':'Organization ABC',
            'nou':'-',
            'noa':'100',
            'nof':'1',
            'nous':'-',
            'nos':'-',
            'noas':'20',
            'nom':'-',
            'logo':'fa fa-forumbee',
            'subOrganisation':[{
                    'id':'1111',
                    'name':'Sub Organization ABC',
                    'nou':'10',
                    'noa':'20',
                    'nof':'40',
                    'logo':'fa fa-forumbee',
            'subOrganisation':[{
                'name':'Sub Organization 1',
                'nou':'-',
                'noa':'100',
                'nof':'1',
                'nous':'-',
                'nos':'-',
                'noas':'20',
                'nom':'-',
                'logo':'fa fa-forumbee'
            },
            {
                    'id':'32',
                    'name':'Sub Organization 2',
                    'nou':'10',
                    'noa':'20',
                    'nof':'40',
                    'nous':'10',
                    'nos':'12',
                    'noas':'10',
                    'nom':'11',
                    'logo':'fa fa-forumbee'
            },
            {
                    'id':'87',
                    'name':' Sub Organization 3',
                    'nou':'-',
                    'noa':'100',
                    'nof':'1',
                    'nous':'-',
                    'nos':'-',
                    'noas':'20',
                    'nom':'-',
                    'logo':'fa fa-forumbee'
            },
            {
                    'id':'92',
                    'name':'Sub Organization 4',
                    'nou':'10',
                    'noa':'20',
                    'nof':'40',
                    'nous':'10',
                    'nos':'12',
                    'noas':'10',
                    'nom':'11',
                    'logo':'fa fa-forumbee'
            }]
            }
            ]
        },
        {
            'id':'1099',
            'name':'CANect Portal',
            'nou':'-',
            'noa':'100',
            'nof':'1',
            'nous':'-',
            'nos':'-',
            'noas':'20',
            'nom':'-',
            'logo':'fa fa-dribbble',
            'subOrganisation':[{
                    'id':'1043',
                    'name':'Sub CANect 1',
                    'nou':'10',
                    'noa':'20',
                    'nof':'40',
                    'nous':'10',
                    'nos':'12',
                    'noas':'10',
                    'nom':'11',
                    'logo':'fa fa-forumbee'
            },
            {
                    'id':'1035',
                    'name':'Sub CANect 2',
                    'nou':'-',
                    'noa':'100',
                    'nof':'1',
                    'nous':'-',
                    'nos':'-',
                    'noas':'20',
                    'nom':'-',
                    'logo':'fa fa-forumbee'
            },
        {
                    'id':'1065',
                    'name':'Sub CANect 3',
                    'nou':'10',
                    'noa':'20',
                    'nof':'40',
                    'nous':'10',
                    'nos':'12',
                    'noas':'10',
                    'nom':'11',
                    'logo':'fa fa-opencart'
            }]
        },
        {
            'id':'1076',
            'name':'Organization Sample',
            'nou':'-',
            'noa':'100',
            'nof':'1',
            'nous':'-',
            'nos':'-',
            'noas':'20',
            'nom':'-',
            'logo':'fa fa-ioxhost'
        },
    ]