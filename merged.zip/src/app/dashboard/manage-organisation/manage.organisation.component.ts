import { Component ,Inject,ChangeDetectorRef  } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import {ManageOrganisationService} from './manage.organisation.service';
import { DOCUMENT } from '@angular/platform-browser';

@Component({
    moduleId: module.id,
    templateUrl: 'manage.organisation.component.html',
    styleUrls: ['manage.organisation.component.css']
})

export class ManageOrganisationComponent {
    public Organisations;
    blank = '-';
    public breadcrum = [{'name':'Main Organisation'}] ;
    public mainOrg = {'name':'Main Organisation','nou':'-',
            'noa':'-',
            'nof':'-',
            'nous':'-',
            'nos':'-',
            'noas':'-',
            'nom':'-',};
    constructor(
        private router: Router,
        private manageservice: ManageOrganisationService,
        private activeRoute:ActivatedRoute,
        private cd: ChangeDetectorRef,
        @Inject(DOCUMENT) private document
) { }
// call search api
getOrganisaion() {

}
    ngOnInit() {
      this.Organisations =   this.manageservice.getAllOrganisation();
   }
    getSubOrganisaiton(event) {
        console.log(event);
        if(event['subOrganisation'] && event['subOrganisation'].length!=0) {
            ///this.document.getElementById('organisation-list');
            this.Organisations = event['subOrganisation'];
            this.mainOrg = event;
            this.breadcrum.push(event);
        }
    }
    navigateTo(crums) {
        if(this.breadcrum.length > 1) {
            let index = this.breadcrum.findIndex(item  => item['id'] == crums.id);
            this.breadcrum.length = index + 1;
            if(this.breadcrum.length == 1) {
                this.Organisations =   this.manageservice.getAllOrganisation();
                this.mainOrg ={'name':'Main Organisation','nou':'-',
            'noa':'-',
            'nof':'-',
            'nous':'-',
            'nos':'-',
            'noas':'-',
            'nom':'-'};
            }
            else {
            this.Organisations = crums['subOrganisation'];
            this.mainOrg = crums;
            }
        }
        
    }
}