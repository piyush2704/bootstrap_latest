import { Component, Inject,ViewEncapsulation  } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';

@Component({
  selector: 'login-root',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
   encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  sub;
  constructor(@Inject(DOCUMENT) private document,private activeRoute:ActivatedRoute) {

  }
  ngOnInit() {
    this.sub = this.activeRoute.queryParams.subscribe(params => {
      let id = params['companyid'];
     console.log(id);
     if(id === "1") {
        this.document.getElementById('theme').setAttribute
        ('href', 'https://www.telerik.com/kendo-angular-ui/npm/node_modules//@progress/kendo-theme-bootstrap/dist/all.css');
        this.document.getElementById('body').setAttribute("style", 'background-image: url("http://www.hedonline.com/HED-Files/Markets/Ag-Market-Page.jpg")');
      }
      else if (id === "2"){
        this.document.getElementById('theme').setAttribute
        ('href', 'https://www.telerik.com/kendo-angular-ui/npm/node_modules//@progress/kendo-theme-material/dist/all.css');
       
        this.document.getElementById('body').setAttribute("style", 'background-image: url("http://www.hedonline.com/HED-Files/Markets/Fire.jpg?")');
        
      } else {
        this.document.getElementById('theme').setAttribute
        ('href', 'https://www.telerik.com/kendo-angular-ui/npm/node_modules//@progress/kendo-theme-default/dist/all.css');
       
      }
   });
  }
}
