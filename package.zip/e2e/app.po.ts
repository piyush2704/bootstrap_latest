import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/login?companyid=1');
  }

  getColor() {
    return element(by.css('.k-button')).getCssValue('background-color');
  }
}

// getbackgroundImage(){
//   return element(by.css('#body').toEqual('http://www.hedonline.com/HED-Files/Markets/Ag-Market-Page.jpg')
// }
// import { browser, by, element } from 'protractor';

// export class CANectPortalPage {
//   navigateTo() {
//     return browser.get('');
//   }
// /* navigateTo() {
//     return browser.get('/login?companyid=1');
//   } */

//   getColor() {
//     return element(by.css('.k-button')).getCssValue('background-color');
//   }
//   getParagraphText() {
//     return element(by.css('app-root h1')).getText();
//   }
//   checkLogin() {
//     var username = element(by.id('username'));
//     var password = element(by.id('password'));
//     username.sendKeys('a');
//     password.sendKeys('a');
//     var login = element(by.css('button'));
//     login.click();
//     var getrecords = browser.wait(function () {
//      return element(by.css("#welcome")).getText();
// }, 10000);
//    // var getrecords = element(by.id("welcome")).getText();
//     return getrecords;

//   }
//   registerUser() {
//     var firstName =element(by.css('#firstName'));
//     var lastName = element(by.model('lastName'));
//     var email = element(by.model('email'));
//     var username = element(by.model('username'));
//     var organisation = element(by.model('organisation'));
//     var title = element(by.model('title'));
//     var employeeID = element(by.model('employeeID'));
//     var phone = element(by.model('phone'));
//     var password = element(by.model('password'));
//     var register =  element(by.buttonText('register').click());
// firstName.sendKeys('praveen');
// lastName.sendKeys('rfr');
// email.sendKeys('p@p.com');
// username.sendKeys('frfr');
// organisation.sendKeys('dell');
// title.sendKeys('Mr.');
// employeeID.sendKeys('123');
// phone.sendKeys('12324324');
// password.sendKeys('1234');
// register.click();    
//   }
// }
