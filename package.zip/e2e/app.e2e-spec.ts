import { AppPage } from './app.po';

describe('canect-portal App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getColor()).toEqual('rgba(255, 99, 88, 1)');
    //expect(page.getbackgroundImage().toEqual('http://www.hedonline.com/HED-Files/Markets/Ag-Market-Page.jpg'))
  });
});
// import { CANectPortalPage } from './app.po';
// import { browser, element, by } from 'protractor';

// describe('canect-portal App', () => {
//   let page: CANectPortalPage;

//   beforeEach(() => {
//     page = new CANectPortalPage();
//   });

//   it('should display message saying app works', () => {
//     page.navigateTo();
//    // page.registerUser();
//    //page.getColor().toEqual('rgba(255, 99, 88, 1)');
//    page.checkLogin();
//   var temp = browser.wait(function () {
//      return element(by.id("welcome")).getText();
// }, 10000);
//     expect(temp).toEqual('Welcome to CANect Portal'); 
//   });
// });
