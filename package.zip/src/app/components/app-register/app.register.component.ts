import { Component } from '@angular/core';
import { Router } from '@angular/router';

import {AuthenticationService } from '../app-login/app.login.service';

@Component({
    moduleId: module.id,
    templateUrl: 'app.register.component.html'
})

export class RegisterComponent {
    model: any = {};
    loading = false;

    constructor(
        private router: Router,
        private userService: AuthenticationService,
) { }

    register() {
        this.loading = true;
        this.userService.create(this.model)
            .subscribe(
                data => {
                    console.log('registration suggessful');
                    this.router.navigate(['/login']);
                },
                error => {
                    alert('registration failed');
                    console.log('registration failed');
                    this.loading = false;
                });
    }
}
