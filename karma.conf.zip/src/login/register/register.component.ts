import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from '../login/login.service';

@Component({
    moduleId: module.id,
    templateUrl: 'register.component.html',
    styleUrls: ['./register.component.css'],
})

export class RegisterComponent {
    model: any = {};
    loading = false;
    sub;
    registerOutlet;
    constructor(
        private router: Router,
        private userService: AuthenticationService,
        private activeRoute: ActivatedRoute
    ) { }

    register() {
        this.loading = true;
        this.userService.create(this.model)
            .subscribe(
            data => {
                console.log('registration suggessful');
                this.router.navigate(['/login'], { queryParams: this.registerOutlet });
            },
            error => {
                alert('registration failed');
                console.log('registration failed');
                this.loading = false;
            });
    }
    ngOnInit() {
        this.sub = this.activeRoute.queryParams.subscribe(params => {
            let id = params['companyid'];
            this.registerOutlet = { 'companyid': id };
        });
    }
}
