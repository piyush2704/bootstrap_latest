import { Component, OnInit, Renderer, ViewChild, AfterViewInit } from '@angular/core';
import { SelectItem, MultiSelect } from 'primeng/primeng';

import { CanectService } from './../../services/index';

@Component({
  selector: 'filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit, AfterViewInit {

  @ViewChild('mso') oms: MultiSelect;
  organizations: any = [];
  fleets: any = [];
  assets: any = [];
  selectedOrganizations: any = [];
  selectedFleets: any = [];
  selectedAssets: any = [];

  filteredArray: any = [];

  filterToggle: boolean = false;

  startDate = "";
  endDate = "";
  startTime = "";
  endTime = "";
  maintenanceStatus = "";
  additionalFilter: boolean = false;

  public listItems: Array<string> = ["Upcoming", "Active", "In-Active", "In-progress", "Overdue", "Assigned", "Onhold", "Complete", "System-complete"];

  constructor(private _canectService: CanectService, private renderer: Renderer) { }

  ngOnInit() {
    this.loadOrganizations();
  }

  ngAfterViewInit() {
    this.renderer.listenGlobal('document', 'click', () => {
      if (!this.oms.selfClick && !this.oms.panelClick && this.oms.overlayVisible) {
        this.loadFleets(this.selectedOrganizations);
        this.loadAssets(this.selectedOrganizations);
      }
    });
  }

  loadOrganizations() {
    return this._canectService.getData('assets/organizations.json').subscribe(data => {
      this.organizations = data;
    },
      error => {
        console.log(error)
      });
  }

  loadFleets(selectedItems) {
    return this._canectService.getData('assets/fleets.json').subscribe(data => {

      this.fleets = [];

      if (selectedItems.includes("Organization1")) {
        this.fleets.push(data[0].FLEET1);
      }
      if (selectedItems.includes("Organization2")) {
        this.fleets.push(data[1].FLEET2);
      }

      if (selectedItems.includes("Organization3")) {
        this.fleets.push(data[2].FLEET3);
      }
      if (selectedItems.includes("Organization4")) {
        this.fleets.push(data[3].FLEET4);
      }
      if (selectedItems.includes("Organization5")) {
        this.fleets.push(data[4].FLEET5);
      }
    },
      error => {
        console.log(error)
      });
  }

  loadAssets(selectedItems) {
    return this._canectService.getData('assets/assets.json').subscribe(data => {

      this.assets = [];

      if (selectedItems.includes("Organization1")) {
        this.assets.push(data[0].ASSET1);
        this.assets.push(data[5].ASSET6);
      }
      if (selectedItems.includes("Organization2")) {
        this.assets.push(data[1].ASSET2);
      }
      if (selectedItems.includes("Organization3")) {
        this.assets.push(data[2].ASSET3);
      }
      if (selectedItems.includes("Organization4")) {
        this.assets.push(data[3].ASSET4);
      }

      if (selectedItems.includes("Organization5")) {
        this.assets.push(data[4].ASSET5);
      }
    },
      error => {
        console.log(error)
      });
  }

  toggleFilter() {
    this.filterToggle = !this.filterToggle;
  }

  clearFilter() {
    this.selectedOrganizations = [];
    this.selectedFleets = [];
    this.selectedAssets = [];
    this.filteredArray = [];
    this.fleets = [];
    this.assets = [];
  }

  applyFilter() {
    this.filteredArray = [];
    this.filteredArray.push(this.selectedOrganizations, this.selectedFleets, this.selectedAssets);
  }

  applyAdditionalFilter() {
    this.additionalFilter = true;
  }

  clearAdditionalFilter() {
    this.additionalFilter = false;
    this.startDate = "";
    this.endDate = "";
    this.startTime = "";
    this.endTime = "";
    this.maintenanceStatus="";
  }

}
