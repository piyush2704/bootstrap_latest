import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

// Kendo - Modules
import { LayoutModule } from '@progress/kendo-angular-layout';
import { DropDownsModule, DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IntlModule } from '@progress/kendo-angular-intl';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';

// PrimeNG - Modules
import { MultiSelectModule } from 'primeng/primeng';

// Internal-Components
import { FilterComponent, FooterComponent, GridComponent, HeaderComponent, SidebarComponent, MapComponent } from './modules/index';

// Services
import { CanectService } from './services/index';

import * as $ from 'jquery';

@NgModule({
    declarations: [],
    imports: [
        FormsModule,
        CommonModule,
        HttpModule,
        ReactiveFormsModule,
        LayoutModule, DropDownsModule, DropDownListModule, GridModule,
        MultiSelectModule, ButtonsModule, IntlModule, DateInputsModule
    ],
    providers: [CanectService],
    exports: []
})

export class SharedModule { }