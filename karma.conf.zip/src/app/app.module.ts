import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { APP_ROUTES } from './app-routing.module';
import { AppComponent } from './app.component';
import { CanectComponent } from './canect.component';
import { RouterModule, Routes } from '@angular/router';

import * as $ from 'jquery';

import { LoginModule } from './../login/login.module';
import { SharedModule } from './../shared/shared.module';
import { DashboardModule } from './dashboard/dashboard.module';

import { PageNotFoundComponent } from './../page-not-found/page-not-found.component';
import { AuthGuard } from './../login/login/authgaurd';


@NgModule({
  declarations: [
    AppComponent,
    CanectComponent,
    PageNotFoundComponent
  ],
  imports: [
    LoginModule,
    SharedModule,
    DashboardModule,
    BrowserModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    RouterModule.forRoot(APP_ROUTES),
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
