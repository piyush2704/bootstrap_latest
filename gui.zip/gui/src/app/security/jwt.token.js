"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var JWTService = (function () {
    function JWTService() {
    }
    JWTService.prototype.getAccessToken = function () {
        return this.accessToken;
    };
    JWTService.prototype.setAccessToken = function (value) {
        this.accessToken = value;
    };
    JWTService.prototype.getIdToken = function () {
        return this.idToken;
    };
    JWTService.prototype.setIdToken = function (value) {
        this.idToken = value;
    };
    //parsing the token
    JWTService.prototype.getAccessTokenAsJSON = function () {
        if (this.accessToken) {
            return this.parseToken(this.accessToken);
        }
    };
    //parsing Id Token
    JWTService.prototype.getIdTokenAsJSON = function () {
        if (this.idToken) {
            return this.parseToken(this.idToken);
        }
    };
    JWTService.prototype.parseToken = function (tokenToParse) {
        if (tokenToParse) {
            var base64Url = tokenToParse.split('.')[1];
            var base64 = base64Url.replace('-', '+').replace('_', '/');
            var object = JSON.parse(window.atob(base64));
            return object;
        }
        return null;
    };
    return JWTService;
}());
JWTService = __decorate([
    core_1.Injectable()
], JWTService);
exports.JWTService = JWTService;
//# sourceMappingURL=jwt.token.js.map