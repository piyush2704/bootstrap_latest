import { Injectable } from '@angular/core';

@Injectable()
export class JWTService {
    private accessToken: string;
    private idToken: string;

    getAccessToken() {
        return this.accessToken;
    }

    setAccessToken(value:string){
        this.accessToken = value;
    }

    getIdToken() {
        return this.idToken;
    }

    setIdToken(value:string) {
        this.idToken = value;
    }

    //parsing the token
    getAccessTokenAsJSON() {
       if (this.accessToken) {
           return this.parseToken(this.accessToken);
       }
    }

    //parsing Id Token
    getIdTokenAsJSON() {
        if(this.idToken) {
           return this.parseToken(this.idToken);
        }
    }

    private parseToken(tokenToParse:string) {
        if (tokenToParse) {
            var base64Url = tokenToParse.split('.')[1];
            var base64 = base64Url.replace('-', '+').replace('_', '/');
            var object = JSON.parse(window.atob(base64));
            return object;
        }

        return null;
    }
}