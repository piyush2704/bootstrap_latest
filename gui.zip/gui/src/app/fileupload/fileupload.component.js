"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var router_1 = require("@angular/router");
var ng2_file_upload_1 = require("ng2-file-upload");
var AWS = require("aws-sdk");
// const URL = '';
var FileuploadComponent = (function () {
    function FileuploadComponent(http, router) {
        this.http = http;
        this.router = router;
        this.uploader = new ng2_file_upload_1.FileUploader({});
        this.reader = new FileReader();
        this.error = false;
        this.success_status = false;
        this.successMsg = '';
        this.errorMsg = '';
        this.disable_status = true;
        this.choose_file_disable_status = false;
    }
    FileuploadComponent.prototype.readthis = function (inputvalue) {
        var file = inputvalue.files[0];
        var myreader = new FileReader();
        myreader.onloadend = function (e) {
            // console.log(myreader.result);
        };
        this.file_payload = myreader.readAsText(file);
    };
    // check_file_test(event): void {
    //
    // }
    FileuploadComponent.prototype.check_file = function (event) {
        // console.log(this.uploader.queue);
        this.readthis(event.target);
        if (this.uploader.queue) {
            if (this.uploader.queue[0].file.type === 'text/csv' || this.uploader.queue[0].file.type === 'text/json') {
                if (this.uploader.queue[0].file.size <= 50000) {
                    if (this.uploader.queue.length > 1) {
                        this.uploader.queue = [];
                        this.error = true;
                        this.errorMsg = 'something went wrong.. try again.';
                    }
                    else {
                        this.disable_status = false;
                        this.choose_file_disable_status = true;
                        this.error = false;
                        this.errorMsg = '';
                    }
                }
                else {
                    // Assuming only one file is allowed to upload,
                    // Reset the queue to empty when there is any error with the type of file being uploaded
                    this.uploader.queue = [];
                    this.errorMsg = 'cannot upload more than 50 KB file';
                }
            }
            else {
                this.uploader.queue = [];
                this.error = true;
                this.errorMsg = 'Only CSV and JSON File types are allowed';
            }
        }
    };
    FileuploadComponent.prototype.clear = function () {
        this.uploader.queue = [];
        this.choose_file_disable_status = false;
    };
    FileuploadComponent.prototype.upload = function () {
        AWS.config.update({
            accessKeyId: 'AKIAJZZTRZBWVCNVIVXQ',
            secretAccessKey: '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'
        });
        AWS.config.region = 'us-east-1';
        this.s3Bucket = new AWS.S3({ params: { Bucket: 'veneeth-bucket-angular' } });
        // upload only if file type is CSV or JSON
        if (this.uploader.queue[0].file.type === 'text/csv' || this.uploader.queue[0].file.type === 'text/json') {
            // file size should be less than or equal to 50KB
            if (this.uploader.queue[0].file.size <= 50000) {
                this.choose_file_disable_status = true;
                if (this.uploader.queue.length > 1) {
                    this.uploader.queue = [];
                    this.error = true;
                    this.errorMsg = 'something went wrong.. try again.';
                }
                else {
                    this.error = false;
                    this.errorMsg = '';
                    this.s3_file_upload();
                }
            }
            else {
                this.uploader.queue = [];
                this.error = true;
                this.errorMsg = 'cannot upload more than 50 KB file';
                // console.log('cannot upload more than 50 KB file');
            }
        }
        else {
            // alert('cannot upload file type other than CSV and JSON');
            this.uploader.queue = [];
            this.error = true;
            this.errorMsg = ' CSV and JSON File types are allowed';
        }
    };
    FileuploadComponent.prototype.s3_file_upload = function () {
        this.request = {
            Key: this.uploader.queue[0].file.name, Body: this.uploader.queue[0]._file,
            Bucket: 'veneeth-bucket-angular'
        };
        this.s3Bucket.upload(this.request, function (err, data) {
        });
    };
    FileuploadComponent.prototype.file_upload = function () {
        // let self = this;
        var xhrRequest = new XMLHttpRequest();
        xhrRequest.open('POST', 'https://y0dy3amq02.execute-api.us-east-1.amazonaws.com/dev/bucket', true);
        xhrRequest.setRequestHeader('Content-Type', 'application/json');
        var file = this.uploader.queue[0]._file;
        var myreader = new FileReader();
        var file_data = '';
        myreader.onloadend = function (e) {
            file_data = myreader.result;
            var payload = JSON.stringify({
                'file_contents': file_data
            });
            xhrRequest.send(payload);
        };
        this.file_payload = myreader.readAsText(file);
        // let self = this;
        // self.uploader.queue[0]._file['url'] = '/users/vineeth.yennam/Downloads/test.csv';
        // console.log(self.uploader.queue[0]._file);
        // console.log(self.reader.readAsDataURLl;(self.uploader.queue[0]._file));
        // let headers = new Headers({'Content-Type': 'application/json'});
        // let formData = new FormData();
        // formData.append(this.uploader.queue[0].file.name, this.uploader.queue[0]._file);
        // this.http.post('https://y0dy3amq02.execute-api.us-east-1.amazonaws.com/dev/bucket',
        // formData, new RequestOptions({headers: headers})).
        //     map((response: Response) => response.json())
        //     .subscribe(
        //         function(response: any) {
        //             console.log(response);
        //         },
        //         function(error: any) {
        //             console.log('Error in upload');
        //             console.log(error);
        //         }
        //     );
        // let formDataToJson = JSON.parse(JSON.stringify(self.uploader.queue[0]));
        // console.log(self.reader.readAsArrayBuffer(self.uploader.queue[0]._file));
        // console.log(formDataToJson);
        // let payload = {
        //     'file_contents': this.f
        // };
        // xhrRequest.send(payload);
        //     Observable.create(function(observer: Observer<string>) {
        //         let xhrRequest: XMLHttpRequest = new XMLHttpRequest();
        //         let formData = new FormData();
        //         formData.append(self.uploader.queue[0].file.name, self.uploader.queue[0]._file);
        //
        //         xhrRequest.onreadystatechange = () => {
        //             if (xhrRequest.readyState === 4) {
        //                 if (xhrRequest.status === 200) {
        //                     observer.next(JSON.parse(xhrRequest.response));
        //                     observer.complete();
        //                 } else {
        //                     observer.error(xhrRequest.response);
        //                 }
        //             }
        //         };
        //
        //         xhrRequest.open('POST', 'https://y0dy3amq02.execute-api.us-east-1.amazonaws.com/dev/bucket', true);
        //          xhrRequest.setRequestHeader('Content-Type', 'application/json');
        //         // let formDataToJson = JSON.parse(JSON.stringify(self.uploader.queue[0]));
        //         // console.log(self.reader.readAsArrayBuffer(self.uploader.queue[0]._file));
        //         // console.log(formDataToJson);
        //         let payload = {
        //             'file_contents': self.file_contents
        //         };
        //         console.log(payload);
        //         xhrRequest.send(payload);
        //     }).subscribe(
        //         function(response: any) {
        //             console.log(response);
        //         },
        //         function(error: any) {
        //            console.log('Error');
        //            console.log(error);
        //         }
        //     );
        // }
    };
    return FileuploadComponent;
}());
FileuploadComponent = __decorate([
    core_1.Component({
        selector: 'fileupload',
        templateUrl: './fileupload-component.html',
        styleUrls: ['./fileupload.component.css']
    })
    // url: URL, disableMultipart: true
    ,
    __metadata("design:paramtypes", [http_1.Http,
        router_1.Router])
], FileuploadComponent);
exports.FileuploadComponent = FileuploadComponent;
//# sourceMappingURL=fileupload.component.js.map