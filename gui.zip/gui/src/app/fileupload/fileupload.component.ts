import {Component} from '@angular/core';
import {Http} from '@angular/http';
import {Router} from '@angular/router';
import {FileUploader} from 'ng2-file-upload';
import * as AWS from 'aws-sdk';

// const URL = '';

@Component({
    selector: 'fileupload', // selector for component
    templateUrl: './fileupload-component.html',
    styleUrls: ['./fileupload.component.css']
})

// url: URL, disableMultipart: true

export class FileuploadComponent {
    public uploader: FileUploader = new FileUploader({});
    public reader: FileReader = new FileReader();
    file_payload: any;
    s3Bucket: any;
    request: any;
    error = false;
    success_status = false;
    successMsg = '';
    errorMsg = '';
    disable_status = true;
    choose_file_disable_status = false;


    constructor(
                private http: Http,
                private router: Router
                ) {
    }
    readthis(inputvalue: any): void {
        let file: File = inputvalue.files[0];
        let myreader: FileReader = new FileReader();
        myreader.onloadend = function (e) {
            // console.log(myreader.result);
        };
        this.file_payload = myreader.readAsText(file);
    }

    // check_file_test(event): void {
    //
    // }
    check_file(event: any): void {
        // console.log(this.uploader.queue);
        this.readthis(event.target);
        if (this.uploader.queue) {
            if (this.uploader.queue[0].file.type === 'text/csv' || this.uploader.queue[0].file.type === 'text/json') {
                if (this.uploader.queue[0].file.size <= 50000) {
                    if (this.uploader.queue.length > 1) {
                        this.uploader.queue = [];
                        this.error = true;
                        this.errorMsg = 'something went wrong.. try again.';

                    } else {
                        this.disable_status = false;
                        this.choose_file_disable_status = true;
                        this.error = false;
                        this.errorMsg = '';
                    }
                } else {
                    // Assuming only one file is allowed to upload,
                    // Reset the queue to empty when there is any error with the type of file being uploaded
                    this.uploader.queue = [];
                    this.errorMsg = 'cannot upload more than 50 KB file';
                }

            } else {
                this.uploader.queue = [];
                this.error = true;
                this.errorMsg = 'Only CSV and JSON File types are allowed';
            }
        }
    }

    public clear() {
        this.uploader.queue = [];
        this.choose_file_disable_status = false;
    }

    public upload() {
        AWS.config.update({
            accessKeyId: 'AKIAJZZTRZBWVCNVIVXQ',
            secretAccessKey: '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'
        });
        AWS.config.region = 'us-east-1';
        this.s3Bucket = new AWS.S3({params: {Bucket: 'veneeth-bucket-angular'}});
        // upload only if file type is CSV or JSON
        if (this.uploader.queue[0].file.type === 'text/csv' || this.uploader.queue[0].file.type === 'text/json') {
            // file size should be less than or equal to 50KB
            if (this.uploader.queue[0].file.size <= 50000) {
                this.choose_file_disable_status = true;
                if (this.uploader.queue.length > 1) {
                    this.uploader.queue = [];
                    this.error = true;
                    this.errorMsg = 'something went wrong.. try again.';
                } else {
                    this.error = false;
                    this.errorMsg = '';
                    this.s3_file_upload();
                }

            } else {
                this.uploader.queue = [];
                this.error = true;
                this.errorMsg = 'cannot upload more than 50 KB file';
                // console.log('cannot upload more than 50 KB file');
            }
        } else {
            // alert('cannot upload file type other than CSV and JSON');
            this.uploader.queue = [];
            this.error = true;
            this.errorMsg = ' CSV and JSON File types are allowed';
        }
    }

    public s3_file_upload() {
        this.request = {
            Key: this.uploader.queue[0].file.name, Body: this.uploader.queue[0]._file,
            Bucket: 'veneeth-bucket-angular'
        };

        this.s3Bucket.upload(this.request, function (err: any, data: any) {
        });
    }

    public file_upload() {
        // let self = this;
        let xhrRequest: XMLHttpRequest = new XMLHttpRequest();
        xhrRequest.open('POST', 'https://y0dy3amq02.execute-api.us-east-1.amazonaws.com/dev/bucket', true);
        xhrRequest.setRequestHeader('Content-Type', 'application/json');

        let file: File = this.uploader.queue[0]._file;
        let myreader: FileReader = new FileReader();
        let file_data = '';
        myreader.onloadend = function (e) {
            file_data  = myreader.result;

            let payload = JSON.stringify({
                'file_contents': file_data
            });
            xhrRequest.send(payload);

        };
        this.file_payload = myreader.readAsText(file);
        // let self = this;
        // self.uploader.queue[0]._file['url'] = '/users/vineeth.yennam/Downloads/test.csv';
        // console.log(self.uploader.queue[0]._file);
        // console.log(self.reader.readAsDataURLl;(self.uploader.queue[0]._file));
        // let headers = new Headers({'Content-Type': 'application/json'});
        // let formData = new FormData();
        // formData.append(this.uploader.queue[0].file.name, this.uploader.queue[0]._file);
        // this.http.post('https://y0dy3amq02.execute-api.us-east-1.amazonaws.com/dev/bucket',
        // formData, new RequestOptions({headers: headers})).
        //     map((response: Response) => response.json())
        //     .subscribe(
        //         function(response: any) {
        //             console.log(response);
        //         },
        //         function(error: any) {
        //             console.log('Error in upload');
        //             console.log(error);
        //         }
        //     );


        // let formDataToJson = JSON.parse(JSON.stringify(self.uploader.queue[0]));
        // console.log(self.reader.readAsArrayBuffer(self.uploader.queue[0]._file));
        // console.log(formDataToJson);

        // let payload = {
        //     'file_contents': this.f
        // };

        // xhrRequest.send(payload);

        //     Observable.create(function(observer: Observer<string>) {
        //         let xhrRequest: XMLHttpRequest = new XMLHttpRequest();
        //         let formData = new FormData();
        //         formData.append(self.uploader.queue[0].file.name, self.uploader.queue[0]._file);
        //
        //         xhrRequest.onreadystatechange = () => {
        //             if (xhrRequest.readyState === 4) {
        //                 if (xhrRequest.status === 200) {
        //                     observer.next(JSON.parse(xhrRequest.response));
        //                     observer.complete();
        //                 } else {
        //                     observer.error(xhrRequest.response);
        //                 }
        //             }
        //         };
        //
        //         xhrRequest.open('POST', 'https://y0dy3amq02.execute-api.us-east-1.amazonaws.com/dev/bucket', true);
        //          xhrRequest.setRequestHeader('Content-Type', 'application/json');
        //         // let formDataToJson = JSON.parse(JSON.stringify(self.uploader.queue[0]));
        //         // console.log(self.reader.readAsArrayBuffer(self.uploader.queue[0]._file));
        //         // console.log(formDataToJson);
        //         let payload = {
        //             'file_contents': self.file_contents
        //         };
        //         console.log(payload);
        //         xhrRequest.send(payload);
        //     }).subscribe(
        //         function(response: any) {
        //             console.log(response);
        //         },
        //         function(error: any) {
        //            console.log('Error');
        //            console.log(error);
        //         }
        //     );
        // }
    }
}
