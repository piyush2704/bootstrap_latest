import { Injectable } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';
import {Observable} from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

declare let AWSCognito: any;
declare let AWS: any;


@Injectable()
export class AwsService {

  constructor(private _http : Http){

  }

  authenticateUserPool(username: any,password: any){

   // console.log("Authenticating User Pool");

    var poolData = {
        UserPoolId: 'us-east-1_Fpn2BMfkQ', //pool id
        ClientId: '2udgc0gai9t3cgodgqv2245m26' //client id
      };

    var userPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
    //console.log("Obtained User Pool", userPool);

    //get the current user from SAML assertion

    var cognitoUser = userPool.getCurrentUser();


   // console.log("Obtained current authenticated user from SAML assertion", cognitoUser);

    if (cognitoUser != null) {
    //  console.log("Current user is null");

      cognitoUser.getSession(function(err:any, session:any) {
        if (err) {
        //  console.log("Error getting current session ", err);
          return;
        }
       // console.log('session validity: ' + session.isValid());

        // NOTE: getSession must be called to authenticate user before calling getUserAttributes
        cognitoUser.getUserAttributes(function(err:any, attributes:any) {
          if (err) {
            // Handle error
          //  console.log("Error getting user attributes ", err);
          } else {
            // Do something with attributes
          }
        });

        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
          IdentityPoolId : 'us-east-1_Fpn2BMfkQ', // your identity pool id here
          Logins : {
            // Change the key below according to the specific region your user pool is in.
            'cognito-idp.us-east-1.amazonaws.com/us-east-1_Fpn2BMfkQ' : session.getIdToken().getJwtToken()
          }
        });

        // Instantiate aws sdk service objects now that the credentials have been updated.
        // example: var s3 = new AWS.S3();

      });
    } else {
     // console.log("Existing CognitoUser is null---try a test with hardcoding the user name/password");
      var userData = {
        Username : username,
        Pool : userPool
      };

      cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

      //console.log("Obtained cognito user befor authentication call", cognitoUser);

      var authenticationData = {
        Username : username,
        Password : password,
      };

      var authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);

      //console.log("Authentication Details: ", authenticationDetails);

      cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function (result:any) {
        //  console.log('access token + ' + result.getAccessToken().getJwtToken());

          //POTENTIAL: Region needs to be set if not already set previously elsewhere.
          AWS.config.region = 'us-east-1';

          AWS.config.credentials = new AWS.CognitoIdentityCredentials({
            IdentityPoolId : 'us-east-1_Fpn2BMfkQ', // your identity pool id here
            Logins : {
              // Change the key below according to the specific region your user pool is in.
              'cognito-idp.us-east-1.amazonaws.com/us-east-1_Fpn2BMfkQ' : result.getIdToken().getJwtToken()
            }
          });

          // Instantiate aws sdk service objects now that the credentials have been updated.
          // example: var s3 = new AWS.S3();

        },

        onFailure: function(err:any) {
        //  console.log("User not authenticated ", err);
        },

      });

    }


    //
    //var userData = {
    //  Username : username,
    //  Pool : userPool
    //};
    //
    //var cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
    //
    //console.log("Obtained cognito user befor authentication call", cognitoUser);
    //
    //var authenticationData = {
    //  Username : username,
    //  Password : password,
    //};
    //
    //var authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);
    //
    //console.log("Authentication Details: ", authenticationDetails);
    //
    //cognitoUser.authenticateUser(authenticationDetails, {
    //  onSuccess: function (result) {
    //    console.log('access token + ' + result.getAccessToken().getJwtToken());
    //
    //    //POTENTIAL: Region needs to be set if not already set previously elsewhere.
    //    AWS.config.region = 'us-east-1';
    //
    //    AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    //      IdentityPoolId : 'us-east-1_Fpn2BMfkQ', // your identity pool id here
    //      Logins : {
    //        // Change the key below according to the specific region your user pool is in.
    //        'cognito-idp.us-east-1.amazonaws.com/us-east-1_Fpn2BMfkQ' : result.getIdToken().getJwtToken()
    //      }
    //    });
    //
    //    // Instantiate aws sdk service objects now that the credentials have been updated.
    //    // example: var s3 = new AWS.S3();
    //
    //  },
    //
    //  onFailure: function(err) {
    //    console.log("User not authenticated ", err);
    //  },
    //
    //});

    //console.log("User after authenticated call", cognitoUser);

  }


}
