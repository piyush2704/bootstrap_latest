"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var search_service_1 = require("./search.service");
var http_1 = require("@angular/http");
var router_1 = require("@angular/router");
var core_2 = require("@angular/core");
var material_1 = require("@angular/material");
require("rxjs/add/operator/startWith");
require("rxjs/add/observable/merge");
require("rxjs/add/operator/map");
var SearchComponent = (function () {
    function SearchComponent(searchService, //inject the UserService
        http, router) {
        this.searchService = searchService;
        this.http = http;
        this.router = router;
        this.displayedColumns = ['Name', 'Type', 'Max Length'];
    }
    SearchComponent.prototype.ngOnInit = function () {
    };
    SearchComponent.prototype.onSearch = function () {
        var _this = this;
        this.searchService.onSearch().subscribe(function (res) {
            _this.dataset = res;
            console.log("Search Results: ", _this.dataset);
        }, function (error) {
            _this.errorStatus = error.status;
            _this.errorMsg = error.message;
        });
    };
    SearchComponent.prototype.onDataSetDetails = function () {
        var _this = this;
        console.log("Click me");
        this.searchService.onDatasetDetails().subscribe(function (res) {
            _this.datasetDetails = res;
            console.log("Dataset Details: ", _this.datasetDetails);
        }, function (error) {
            _this.errorStatus = error.status;
            _this.errorMsg = error.message;
        });
    };
    SearchComponent.prototype.onLinkClick = function ($event) {
        console.log($event.index);
        if ($event.index == 1) {
            this.onDataSetDetails();
        }
    };
    return SearchComponent;
}());
__decorate([
    core_2.ViewChild(material_1.MatPaginator),
    __metadata("design:type", material_1.MatPaginator)
], SearchComponent.prototype, "paginator", void 0);
SearchComponent = __decorate([
    core_1.Component({
        selector: 'my-search',
        templateUrl: './search-component.html',
        providers: [search_service_1.SearchService],
        styleUrls: ['./../assets/css/app.component.css']
    }),
    __metadata("design:paramtypes", [search_service_1.SearchService,
        http_1.Http,
        router_1.Router])
], SearchComponent);
exports.SearchComponent = SearchComponent;
//# sourceMappingURL=search.component.js.map