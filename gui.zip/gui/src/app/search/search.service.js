"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
var jwt_token_1 = require("../security/jwt.token");
var SearchService = (function () {
    function SearchService(http, jwtService) {
        this.http = http;
        this.jwtService = jwtService;
        this.baseUserUrl = 'https://qy71knc6l8.execute-api.us-east-1.amazonaws.com/dev';
    }
    SearchService.prototype.onSearch = function () {
        return this.http.get(this.baseUserUrl + "/" + "v1/catalog/datasets", { headers: this.getHeaders() })
            .map(this.extractData)
            .catch(this.handleError);
    };
    SearchService.prototype.onDatasetDetails = function () {
        return this.http.get(this.baseUserUrl + "/" + "v1/catalog/datasets/1", { headers: this.getHeaders() })
            .map(this.extractDatasetData)
            .catch(this.handleError);
    };
    SearchService.prototype.extractDatasetData = function (res) {
        var body = res.json().data;
        return body || {};
    };
    SearchService.prototype.extractData = function (res) {
        var body = res.json().data;
        return body || {};
    };
    SearchService.prototype.handleError = function (error) {
        console.log("Error: ", error);
        var errMsg;
        if (error.status == 404) {
            var errorObject_1 = { status: error.status, message: "Service is unreachable " + error.url };
            return Observable_1.Observable.throw(errorObject_1);
        }
        if (error.status == 401) {
            var errorObject_2 = { status: error.status, message: error.json().message };
            return Observable_1.Observable.throw(errorObject_2);
        }
        errMsg = error.json().errors[0].detail;
        var errorObject = { status: error.status, message: errMsg };
        return Observable_1.Observable.throw(errorObject);
    };
    SearchService.prototype.getHeaders = function () {
        var headers = new http_1.Headers();
        console.log("Parsed idToken: ", this.jwtService.getIdTokenAsJSON());
        headers.append('Authorization', this.jwtService.getIdToken());
        return headers;
    };
    SearchService.prototype.postHeaders = function () {
    };
    return SearchService;
}());
SearchService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http, jwt_token_1.JWTService])
], SearchService);
exports.SearchService = SearchService;
//# sourceMappingURL=search.service.js.map