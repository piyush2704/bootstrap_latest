export class DatasetDetails {
    name?:string;
    type?:string;
    maxLength?:string;
}
