"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DatasetDetails = (function () {
    function DatasetDetails() {
    }
    return DatasetDetails;
}());
exports.DatasetDetails = DatasetDetails;
//# sourceMappingURL=DatasetDetails.js.map