export class Dataset {
    results?:string;
}
