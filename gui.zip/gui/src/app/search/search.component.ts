import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { Dataset } from './dataset';
import { DatasetDetails } from './DatasetDetails';
import { SearchService } from './search.service';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import {ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/observable/merge';
import 'rxjs/add/operator/map';

@Component({
    selector: 'my-search', //selector for component
    templateUrl: './search-component.html',
    providers: [SearchService],
    styleUrls: ['./../assets/css/app.component.css']

})


export class SearchComponent implements OnInit {

    dataset:Dataset;
    datasetDetails:DatasetDetails;
    errorMsg:string;
    errorStatus:number;

    displayedColumns = ['Name', 'Type', 'Max Length'];

    @ViewChild(MatPaginator) paginator:MatPaginator;

    constructor(private searchService:SearchService, //inject the UserService
                private http:Http,
                private router:Router) {
    }

    ngOnInit():void {
    }

    onSearch():void {
        this.searchService.onSearch().subscribe(res => {
            this.dataset = res;
            console.log("Search Results: ", this.dataset);
        }, error => {
            this.errorStatus = error.status;
            this.errorMsg = error.message;
        });
    }

    onDataSetDetails():void {
        console.log("Click me");
        this.searchService.onDatasetDetails().subscribe(res => {
            this.datasetDetails = res;
            console.log("Dataset Details: ", this.datasetDetails);
        }, error => {
            this.errorStatus = error.status;
            this.errorMsg = error.message;
        });
    }

    onLinkClick($event: any) {
        console.log($event.index);

        if ($event.index == 1) {  //Columns Tab Clicked
            this.onDataSetDetails();
        }
    }
}










