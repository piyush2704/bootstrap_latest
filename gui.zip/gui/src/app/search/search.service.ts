import { Injectable } from '@angular/core';
import { Dataset } from './dataset';
import { DatasetDetails } from './DatasetDetails';
import { Headers, Http, Response } from '@angular/http';
import {Observable} from "rxjs/Observable";
import { JWTService } from '../security/jwt.token';

@Injectable()
export class SearchService {
  private baseUserUrl: string = 'https://qy71knc6l8.execute-api.us-east-1.amazonaws.com/dev';

  constructor(private http : Http,private jwtService: JWTService){
  }

  onSearch(): Observable<Dataset> {
    return this.http.get(this.baseUserUrl+"/" + "v1/catalog/datasets", {headers: this.getHeaders()})
        .map(this.extractData)
        .catch(this.handleError);
  }

  onDatasetDetails(): Observable<DatasetDetails> {
    return this.http.get(this.baseUserUrl+"/" + "v1/catalog/datasets/1", {headers: this.getHeaders()})
        .map(this.extractDatasetData)
        .catch(this.handleError);
  }

  private extractDatasetData(res: Response) {
    let body = res.json().data;
    return body || {};
  }

  private extractData(res: Response) {
    let body = res.json().data;
    return body || {};
  }

  private handleError(error: Response | any) {
    console.log("Error: ", error);

    let errMsg: string;

    if (error.status == 404) {
      const errorObject = {status: error.status, message: "Service is unreachable "+ error.url};
      return Observable.throw(errorObject);
    }

    if (error.status == 401) {
      const errorObject = {status: error.status, message: error.json().message};
      return Observable.throw(errorObject);
    }

    errMsg = error.json().errors[0].detail;
    const errorObject = { status: error.status, message: errMsg };
    return Observable.throw(errorObject);

  }

  private getHeaders(){
    let headers = new Headers();
    console.log("Parsed idToken: ", this.jwtService.getIdTokenAsJSON());
    headers.append('Authorization', this.jwtService.getIdToken());
    return headers;
  }

  private postHeaders() {

  }


}
