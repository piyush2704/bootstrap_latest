"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Extraction = (function () {
    function Extraction(key, label) {
    }
    return Extraction;
}());
exports.Extraction = Extraction;
//# sourceMappingURL=ExtractionProcess.js.map