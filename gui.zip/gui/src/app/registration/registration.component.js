"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var registration_service_1 = require("./registration.service");
var http_1 = require("@angular/http");
var forms_1 = require("@angular/forms");
var RegistrationComponent = (function () {
    function RegistrationComponent(route, registrationServcie, http) {
        var _this = this;
        this.route = route;
        this.registrationServcie = registrationServcie;
        this.http = http;
        this.showDetails = false;
        this.showSource = true;
        this.showStructure = false;
        this.filterText = '';
        this.dataset = {
            'datasetName': '',
            'description': '',
            'org': 'all',
            'stakeholder': '',
            'source': null,
            'fileFormat': 'csv',
            'frequency': '',
            'extractionProcess': 'automatic',
            'extractionType': 'DEI',
            'group': '',
            'dataSensitivity': '',
            'crossAccountAlias': [],
            'partitionFields': '',
            'retentionPolicy': '',
            'role': ''
        };
        this.dropdown_options = {
            extraction_type: [],
            roles: [],
            file_format: [],
            sensitivity: [],
            persons: [],
            frequency: [],
            organization: [],
            partitionBy: [],
            extraction_process: []
        };
        this.selectedCrossAccount = '';
        this.crossAccountModel = [];
        this.extraction_type_automatic = true;
        this.registration_status = false;
        this.pattern = /^[a-zA-Z- ]+$/;
        this.registration_status = false;
        this.personsFormCntrl = new forms_1.FormControl();
        this.filteredPersons = this.personsFormCntrl.valueChanges.startWith(null).
            map(function (person) { return person ? _this.filterPersons(person) : _this.dropdown_options.persons.slice(); });
    }
    RegistrationComponent.prototype.filterPersons = function (personName) {
        return this.dropdown_options.persons.filter(function (person) { return person.toLowerCase().indexOf(personName.toLowerCase()) === 0; });
    };
    RegistrationComponent.prototype.onAnchorClick = function (navRoute) {
        console.log('clicking anchor to go to this route: ' + navRoute);
        console.log('button->' + document.getElementById('dtlButton'));
        if (navRoute === 'details') {
            this.showDetails = true;
            this.showSource = false;
            this.showStructure = false;
        }
        else if (navRoute === 'source') {
            this.showDetails = false;
            this.showSource = true;
            this.showStructure = false;
        }
        else if (navRoute === 'structure') {
            this.showDetails = false;
            this.showSource = false;
            this.showStructure = true;
        }
    };
    RegistrationComponent.prototype.onChangeVal = function (value) {
        if (value === 'all') {
            this.dataset.org = 'all';
        }
        else {
            this.dataset.org = 'inc';
        }
    };
    RegistrationComponent.prototype.onExtractionProcessChange = function (extraction_process) {
        if (extraction_process === 'manual') {
            this.extraction_type_automatic = false;
            this.dataset.extractionType = null;
        }
        else {
            this.extraction_type_automatic = true;
            this.dataset.group = null;
            this.dataset.extractionType = 'DEI';
        }
    };
    RegistrationComponent.prototype.updateCrossAccountAccess = function () {
        this.dataset.crossAccountAlias.push({
            'account': String(this.selectedCrossAccount),
            'role': String(this.dataset.role)
        });
        this.crossAccountModel.push({
            'account': String(this.selectedCrossAccount),
            'role': String(this.dataset.role)
        });
    };
    RegistrationComponent.prototype.onClose = function (event) {
        //   var current_element = event.target.innerText || event.srcElement.innerText;
        var current_cross_aliases = {
            'account': String(event.path[1].childNodes[0].data.trim().split(':')[0].trim()),
            'role': String(event.path[1].childNodes[0].data.trim().split(':')[1].trim())
        };
        for (var i = 0; i < this.crossAccountModel.length; i++) {
            if (this.crossAccountModel[i].account === current_cross_aliases.account
                && this.crossAccountModel[i].role === current_cross_aliases.role) {
                this.crossAccountModel.splice(i, 1);
                break;
            }
        }
        for (var i = 0; i < this.dataset.crossAccountAlias.length; i++) {
            if (this.dataset.crossAccountAlias[i].account === current_cross_aliases.account
                && this.dataset.crossAccountAlias[i].role === current_cross_aliases.role) {
                this.dataset.crossAccountAlias.splice(i, 1);
                break;
            }
        }
    };
    RegistrationComponent.prototype.onNavNext = function () {
        var _this = this;
        this.registrationServcie
            .registerDataset(this.dataset).then(function (res) {
            //   console.log(res.bucketName);
            _this.error_msg = '';
            _this.success_msg = res.bucketName;
            _this.reset_to_default_dataset_val();
        }, function (error) {
            console.log(error);
            _this.success_msg = '';
            _this.error_msg = error.message;
        });
        if (this.dataset.datasetName === '' || this.dataset.description === ''
            || this.dataset.frequency === '' || this.dataset.dataSensitivity === ''
            || this.dataset.crossAccountAlias.length === 0 || this.dataset.partitionFields === ''
            || this.dataset.role === '') {
            this.error_msg = 'Please fill all the fields before submitting.';
        }
        else if (this.dataset.extractionType === 'manual') {
            if (this.dataset.group === '') {
                this.error_msg = 'Group Name cannot be empty';
            }
        }
        else {
            var ds_name = this.dataset.datasetName.toLocaleLowerCase().trim();
            if (ds_name.match(this.pattern)) {
                this.dataset.datasetName = (ds_name.replace(/\s+/g, '-'))
                    .replace(/-{2,}/g, '-');
                this.registrationServcie
                    .registerDataset(this.dataset).then(function (res) {
                    //   console.log(res.bucketName);
                    _this.error_msg = '';
                    _this.success_msg = res.bucketName;
                    _this.reset_to_default_dataset_val();
                }, function (error) {
                    console.log(error);
                    _this.success_msg = '';
                    _this.error_msg = error.message;
                });
            }
            else {
                this.error_msg = 'Dataset Name should contain only letters, dashes and space';
            }
        }
    };
    RegistrationComponent.prototype.reset_to_default_dataset_val = function () {
        this.registration_status = true;
        this.dataset.datasetName = '';
        this.dataset.description = '';
        this.dataset.org = 'all';
        this.dataset.stakeholder = '';
        this.dataset.source = null;
        this.dataset.fileFormat = 'csv';
        this.dataset.frequency = '';
        this.dataset.extractionProcess = 'automatic';
        this.dataset.extractionType = 'DEI';
        this.dataset.group = '';
        this.dataset.dataSensitivity = '';
        this.dataset.crossAccountAlias = [];
        //   Removing the GUI element
        this.crossAccountModel = [];
        this.dataset.partitionFields = '';
        this.dataset.retentionPolicy = '';
        this.dataset.role = '';
    };
    ;
    RegistrationComponent.prototype.onProdDeploy = function () {
        console.log('prod deploy');
        //   console.log('Dataset Name: ' + this.dataset.datasetName);
    };
    RegistrationComponent.prototype._getGuiOptions = function () {
        var _this = this;
        this.registrationServcie.getGuiOptions().then(function (res) {
            _this.dropdown_options['extraction_type'] = res['attributes']['extraction_type'];
            _this.dropdown_options['roles'] = res['attributes']['roles'];
            _this.dropdown_options['file_format'] = res['attributes']['file_format'];
            _this.dropdown_options['sensitivity'] = res['attributes']['sensitivity'];
            _this.dropdown_options['persons'] = res['attributes']['persons'];
            _this.dropdown_options['frequency'] = res['attributes']['frequency'];
            _this.dropdown_options['organization'] = res['attributes']['organization'];
            _this.dropdown_options['partitionBy'] = res['attributes']['partitionBy'];
            _this.dropdown_options['extraction_process'] = res['attributes']['extraction_process'];
        }, function (error) {
            _this.dropdown_options = null;
        });
    };
    RegistrationComponent.prototype.ngOnInit = function () {
        console.log('Launching: ');
        this._getGuiOptions();
    };
    ;
    RegistrationComponent.prototype.onSubmit = function () {
        console.log('on submit');
    };
    return RegistrationComponent;
}());
RegistrationComponent = __decorate([
    core_1.Component({
        selector: 'my-registration',
        templateUrl: './registration-component.html',
        providers: [registration_service_1.RegistrationService],
        styleUrls: ['./../assets/css/material-bootstrap-wizard.css', './../assets/css/app.component.css']
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute,
        registration_service_1.RegistrationService, http_1.Http])
], RegistrationComponent);
exports.RegistrationComponent = RegistrationComponent;
//# sourceMappingURL=registration.component.js.map