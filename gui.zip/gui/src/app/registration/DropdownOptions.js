"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DropdownOptionsModel = (function () {
    function DropdownOptionsModel() {
    }
    return DropdownOptionsModel;
}());
exports.DropdownOptionsModel = DropdownOptionsModel;
//# sourceMappingURL=DropdownOptions.js.map