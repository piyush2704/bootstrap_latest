
export class Dataset {
    datasetName?: string;
    description?: string;
    org?: string;
    stakeholder?: string;
    source?: string;
    fileFormat?: string;
    frequency?: string;
    extractionProcess?: string;
    extractionType?: string;
    group?: string;
    dataSensitivity?: string;
    crossAccountAlias?: Array<{'account': string, 'role': string}>;
    partitionFields?: string;
    retentionPolicy?: string;
    role?: string;
}
