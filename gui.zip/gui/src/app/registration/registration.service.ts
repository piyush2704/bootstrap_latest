import {Injectable} from '@angular/core';

import {Dataset} from './dataset';
import {Headers, Http} from '@angular/http';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';


@Injectable()
export class RegistrationService {
    private baseUserUrl: string = 'https://y0dy3amq02.execute-api.us-east-1.amazonaws.com/dev/bucket';
    private optionsUrl: string = 'https://qy71knc6l8.execute-api.us-east-1.amazonaws.com/dev/v1/catalog/options';
    constructor(private http: Http) {
    }

    registerDataset(dataset: Dataset): Promise<any> {


        let headers = new Headers();
            headers.append('Authorization', '');


        return this.http.post(this.baseUserUrl, {}, {headers: headers})
            .toPromise()
            .then(response => response.json())
            .catch(reject => reject.json());
    }

    getGuiOptions(): Promise<any> {
        let headers = new Headers();
        headers.append('Authorization', '');
        return this.http.get(this.optionsUrl)
            .toPromise()
            .then(response => response.json().data)
            .catch(reject => reject);
    }
}
