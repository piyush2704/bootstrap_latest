"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Dataset = (function () {
    function Dataset() {
    }
    return Dataset;
}());
exports.Dataset = Dataset;
//# sourceMappingURL=dataset.js.map