import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Dataset} from './dataset';
import {DropdownOptionsModel} from './DropdownOptions';

import {RegistrationService} from './registration.service';
import {Http} from '@angular/http';
import {FormGroup, FormControl} from '@angular/forms';
import {Observable} from "rxjs/Observable";


@Component({
    selector: 'my-registration',
    templateUrl: './registration-component.html',
    providers: [RegistrationService],
    styleUrls: ['./../assets/css/material-bootstrap-wizard.css', './../assets/css/app.component.css']
})


export class RegistrationComponent implements OnInit {
    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    showDetails: boolean = false;
    showSource: boolean = true;
    showStructure: boolean = false;
    filterText: string = '';
    dataset: Dataset = {
        'datasetName': '',
        'description': '',
        'org': 'all', //   default value is all.
        'stakeholder': '',
        'source': null,
        'fileFormat': 'csv',
        'frequency': '',
        'extractionProcess': 'automatic',
        'extractionType': 'DEI',
        'group': '',
        'dataSensitivity': '',
        'crossAccountAlias': [],
        'partitionFields': '',
        'retentionPolicy': '',
        'role': ''
    };
    dropdown_options: DropdownOptionsModel = {
        extraction_type: [],
        roles: [],
        file_format: [],
        sensitivity: [],
        persons: [],
        frequency: [],
        organization: [],
        partitionBy: [],
        extraction_process: []
    };

    selectedCrossAccount: string = '';
    crossAccountModel: Array<{ 'account': string, 'role': string }> = [];
    extraction_type_automatic: boolean = true;
    error_msg: string;
    success_msg: string;
    registration_status: boolean = false;
    pattern = /^[a-zA-Z- ]+$/;
    personsFormCntrl: FormControl;
    filteredPersons: Observable<any[]>


    constructor(private route: ActivatedRoute,
                private registrationServcie: RegistrationService, private http: Http) {
        this.registration_status = false;
        this.personsFormCntrl = new FormControl();
        this.filteredPersons = this.personsFormCntrl.valueChanges.startWith(null).
            map(person => person ? this.filterPersons(person) : this.dropdown_options.persons.slice());
    }

    filterPersons(personName: string) {
        return this.dropdown_options.persons.filter(person => person.toLowerCase().indexOf(personName.toLowerCase()) === 0);
    }

    onAnchorClick(navRoute: string) {
        console.log('clicking anchor to go to this route: ' + navRoute);
        console.log('button->' + document.getElementById('dtlButton'));

        if (navRoute === 'details') {
            this.showDetails = true;
            this.showSource = false;
            this.showStructure = false;
        } else if (navRoute === 'source') {
            this.showDetails = false;
            this.showSource = true;
            this.showStructure = false;
        } else if (navRoute === 'structure') {
            this.showDetails = false;
            this.showSource = false;
            this.showStructure = true;
        }


    }

    onChangeVal(value: String) {

        if (value === 'all') {
            this.dataset.org = 'all';
        } else {
            this.dataset.org = 'inc';
        }
    }

    onExtractionProcessChange(extraction_process: string) {

        if (extraction_process === 'manual') {
            this.extraction_type_automatic = false;
            this.dataset.extractionType = null;
        } else {
            this.extraction_type_automatic = true;
            this.dataset.group = null;
            this.dataset.extractionType = 'DEI';
        }
    }

    updateCrossAccountAccess() {


        this.dataset.crossAccountAlias.push({
            'account': String(this.selectedCrossAccount),
            'role': String(this.dataset.role)
        });

        this.crossAccountModel.push({
            'account': String(this.selectedCrossAccount),
            'role': String(this.dataset.role)
        });

    }

    onClose(event: any) {

        //   var current_element = event.target.innerText || event.srcElement.innerText;

        let current_cross_aliases = {
            'account': String(event.path[1].childNodes[0].data.trim().split(':')[0].trim()),
            'role': String(event.path[1].childNodes[0].data.trim().split(':')[1].trim())
        };

        for (let i = 0; i < this.crossAccountModel.length; i++) {
            if (this.crossAccountModel[i].account === current_cross_aliases.account
                && this.crossAccountModel[i].role === current_cross_aliases.role) {
                this.crossAccountModel.splice(i, 1);
                break;
            }
        }
        for (let i = 0; i < this.dataset.crossAccountAlias.length; i++) {
            if (this.dataset.crossAccountAlias[i].account === current_cross_aliases.account
                && this.dataset.crossAccountAlias[i].role === current_cross_aliases.role) {
                this.dataset.crossAccountAlias.splice(i, 1);
                break;
            }
        }
    }

    onNavNext() {


        this.registrationServcie
            .registerDataset(this.dataset).then(res => {

            //   console.log(res.bucketName);
            this.error_msg = '';
            this.success_msg = res.bucketName;
            this.reset_to_default_dataset_val();
        }, error => {
            console.log(error);
            this.success_msg = '';
            this.error_msg = error.message;
        });


        if (this.dataset.datasetName === '' || this.dataset.description === ''
            || this.dataset.frequency === '' || this.dataset.dataSensitivity === ''
            || this.dataset.crossAccountAlias.length === 0 || this.dataset.partitionFields === ''
            || this.dataset.role === ''
        ) {
            this.error_msg = 'Please fill all the fields before submitting.';
        } else if (this.dataset.extractionType === 'manual') {
            if (this.dataset.group === '') {
                this.error_msg = 'Group Name cannot be empty';
            }
        } else {

            let ds_name = this.dataset.datasetName.toLocaleLowerCase().trim();
            if (ds_name.match(this.pattern)) {

                this.dataset.datasetName = (ds_name.replace(/\s+/g, '-'))
                    .replace(/-{2,}/g, '-');
                this.registrationServcie
                    .registerDataset(this.dataset).then(res => {

                    //   console.log(res.bucketName);
                    this.error_msg = '';
                    this.success_msg = res.bucketName;
                    this.reset_to_default_dataset_val();
                }, error => {
                    console.log(error);
                    this.success_msg = '';
                    this.error_msg = error.message;
                });
            } else {
                this.error_msg = 'Dataset Name should contain only letters, dashes and space';
            }
        }


    }

    reset_to_default_dataset_val() {

        this.registration_status = true;
        this.dataset.datasetName = '';
        this.dataset.description = '';
        this.dataset.org = 'all';
        this.dataset.stakeholder = '';
        this.dataset.source = null;
        this.dataset.fileFormat = 'csv';
        this.dataset.frequency = '';
        this.dataset.extractionProcess = 'automatic';
        this.dataset.extractionType = 'DEI';
        this.dataset.group = '';
        this.dataset.dataSensitivity = '';
        this.dataset.crossAccountAlias = [];
        //   Removing the GUI element
        this.crossAccountModel = [];
        this.dataset.partitionFields = '';
        this.dataset.retentionPolicy = '';
        this.dataset.role = '';
    };

    onProdDeploy() {
        console.log('prod deploy');
        //   console.log('Dataset Name: ' + this.dataset.datasetName);
    }

    _getGuiOptions(): void {

        this.registrationServcie.getGuiOptions().then(res => {
            this.dropdown_options['extraction_type'] = res['attributes']['extraction_type'];
            this.dropdown_options['roles'] = res['attributes']['roles'];
            this.dropdown_options['file_format'] = res['attributes']['file_format'];
            this.dropdown_options['sensitivity'] = res['attributes']['sensitivity'];
            this.dropdown_options['persons'] = res['attributes']['persons'];
            this.dropdown_options['frequency'] = res['attributes']['frequency'];
            this.dropdown_options['organization'] = res['attributes']['organization'];
            this.dropdown_options['partitionBy'] = res['attributes']['partitionBy'];
            this.dropdown_options['extraction_process'] = res['attributes']['extraction_process'];
        }, error => {
            this.dropdown_options = null;
        });
    }

    ngOnInit(): void {
        console.log('Launching: ');
        this._getGuiOptions();
    };

    onSubmit(): void {
        console.log('on submit');
    }
}







