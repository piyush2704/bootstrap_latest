export class DropdownOptionsModel {
    extraction_type?: Array<string>;
    roles?: Array<string>;
    file_format?: Array<string>;
    sensitivity?: Array<string>;
    persons?: Array<string>;
    frequency?: Array<string>;
    organization?: Array<string>;
    partitionBy?: Array<string>;
    role?: Array<string>;
    extraction_process?: Array<string>;
}