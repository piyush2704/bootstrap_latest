import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms'; // <-- NgModel Lives Here
import { RouterModule }   from '@angular/router'; // <-- Handles routing for button clicks and links
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; //<-- Angular Material animation components live here
import { HttpModule }    from '@angular/http'; //<-- Handles Http Requests
import { AwsService } from '../app/aws.service';


import {
        MatTabsModule,
        MatRadioModule,
        MatCardModule,
        MatButtonModule,
        MatToolbarModule,
        MatMenuModule,
        MatSidenavModule,
        MatInputModule,
        MatGridListModule,
        MatSelectModule,
        MatExpansionModule,
        MatChipsModule,
        MatListModule,
        MatSlideToggleModule,
        MatStepperModule,
        MatAutocompleteModule
} from '@angular/material'; //<-- Angular Material Components Live Here



import { AppComponent }  from './app.component';
import { UserComponent } from './user/user.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegistrationComponent } from './registration/registration.component';
import { SearchComponent } from './search/search.component';
import {JWTService} from "./security/jwt.token";
import {FeedbackComponent} from "./feedback/feedback.component";
import {FileuploadComponent} from "./fileupload/fileupload.component";


import { FileUploadModule } from 'ng2-file-upload';


@NgModule({
    imports: [
        BrowserModule,
        FormsModule, // <-- import the FormsModule before binding with [(ngModel)]
        ReactiveFormsModule,
        HttpModule,
        BrowserAnimationsModule,
        MatTabsModule,
        MatRadioModule,
        MatCardModule, // <-- import the MatCardModule before using a card in code
        MatButtonModule,  // <-- import the MatButtonModule before using buttons in code
        MatToolbarModule, // <-- import the MatToolbarModule before using toolbars in code
        MatMenuModule, //form element
        MatSidenavModule, //form element
        MatInputModule, //form element
        MatGridListModule,
        MatSlideToggleModule, //form element
        MatSelectModule,
        MatExpansionModule,
        MatChipsModule,
        MatListModule,
        MatStepperModule,
        // MatIconModule,
        MatAutocompleteModule,
        /*FileUploadModule,*/
        FileUploadModule,
        RouterModule.forRoot([
            {
                path: 'user',
                component: UserComponent
            },
            {
                path: 'dashboard',
                component: DashboardComponent
            },
            {
                path: 'registration',
                component: RegistrationComponent
            },
            {
                path: 'search',
                component: SearchComponent
            },
            {
                path: 'feedback',
                component: FeedbackComponent
            },
            {
                path: 'fileupload',
                component: FileuploadComponent
            },
            {
                path: '',
                redirectTo: '/dashboard',
                pathMatch: 'full'
            }
        ])

    ],
    declarations: [
        AppComponent,
        UserComponent,
        DashboardComponent,
        RegistrationComponent,
        SearchComponent,
        FeedbackComponent,
        FileuploadComponent


    ],
    providers: [
        AwsService,
        JWTService
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
