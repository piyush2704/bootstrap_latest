"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/map");
require("rxjs/add/operator/catch");
var AwsService = (function () {
    function AwsService(_http) {
        this._http = _http;
    }
    AwsService.prototype.authenticateUserPool = function (username, password) {
        // console.log("Authenticating User Pool");
        var poolData = {
            UserPoolId: 'us-east-1_Fpn2BMfkQ',
            ClientId: '2udgc0gai9t3cgodgqv2245m26' //client id
        };
        var userPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
        //console.log("Obtained User Pool", userPool);
        //get the current user from SAML assertion
        var cognitoUser = userPool.getCurrentUser();
        // console.log("Obtained current authenticated user from SAML assertion", cognitoUser);
        if (cognitoUser != null) {
            //  console.log("Current user is null");
            cognitoUser.getSession(function (err, session) {
                if (err) {
                    //  console.log("Error getting current session ", err);
                    return;
                }
                // console.log('session validity: ' + session.isValid());
                // NOTE: getSession must be called to authenticate user before calling getUserAttributes
                cognitoUser.getUserAttributes(function (err, attributes) {
                    if (err) {
                        // Handle error
                        //  console.log("Error getting user attributes ", err);
                    }
                    else {
                        // Do something with attributes
                    }
                });
                AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                    IdentityPoolId: 'us-east-1_Fpn2BMfkQ',
                    Logins: {
                        // Change the key below according to the specific region your user pool is in.
                        'cognito-idp.us-east-1.amazonaws.com/us-east-1_Fpn2BMfkQ': session.getIdToken().getJwtToken()
                    }
                });
                // Instantiate aws sdk service objects now that the credentials have been updated.
                // example: var s3 = new AWS.S3();
            });
        }
        else {
            // console.log("Existing CognitoUser is null---try a test with hardcoding the user name/password");
            var userData = {
                Username: username,
                Pool: userPool
            };
            cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
            //console.log("Obtained cognito user befor authentication call", cognitoUser);
            var authenticationData = {
                Username: username,
                Password: password,
            };
            var authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);
            //console.log("Authentication Details: ", authenticationDetails);
            cognitoUser.authenticateUser(authenticationDetails, {
                onSuccess: function (result) {
                    //  console.log('access token + ' + result.getAccessToken().getJwtToken());
                    //POTENTIAL: Region needs to be set if not already set previously elsewhere.
                    AWS.config.region = 'us-east-1';
                    AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                        IdentityPoolId: 'us-east-1_Fpn2BMfkQ',
                        Logins: {
                            // Change the key below according to the specific region your user pool is in.
                            'cognito-idp.us-east-1.amazonaws.com/us-east-1_Fpn2BMfkQ': result.getIdToken().getJwtToken()
                        }
                    });
                    // Instantiate aws sdk service objects now that the credentials have been updated.
                    // example: var s3 = new AWS.S3();
                },
                onFailure: function (err) {
                    //  console.log("User not authenticated ", err);
                },
            });
        }
        //
        //var userData = {
        //  Username : username,
        //  Pool : userPool
        //};
        //
        //var cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
        //
        //console.log("Obtained cognito user befor authentication call", cognitoUser);
        //
        //var authenticationData = {
        //  Username : username,
        //  Password : password,
        //};
        //
        //var authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);
        //
        //console.log("Authentication Details: ", authenticationDetails);
        //
        //cognitoUser.authenticateUser(authenticationDetails, {
        //  onSuccess: function (result) {
        //    console.log('access token + ' + result.getAccessToken().getJwtToken());
        //
        //    //POTENTIAL: Region needs to be set if not already set previously elsewhere.
        //    AWS.config.region = 'us-east-1';
        //
        //    AWS.config.credentials = new AWS.CognitoIdentityCredentials({
        //      IdentityPoolId : 'us-east-1_Fpn2BMfkQ', // your identity pool id here
        //      Logins : {
        //        // Change the key below according to the specific region your user pool is in.
        //        'cognito-idp.us-east-1.amazonaws.com/us-east-1_Fpn2BMfkQ' : result.getIdToken().getJwtToken()
        //      }
        //    });
        //
        //    // Instantiate aws sdk service objects now that the credentials have been updated.
        //    // example: var s3 = new AWS.S3();
        //
        //  },
        //
        //  onFailure: function(err) {
        //    console.log("User not authenticated ", err);
        //  },
        //
        //});
        //console.log("User after authenticated call", cognitoUser);
    };
    return AwsService;
}());
AwsService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], AwsService);
exports.AwsService = AwsService;
//# sourceMappingURL=aws.service.js.map