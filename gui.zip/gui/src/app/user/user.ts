export class User {
    id?: number;
    fname?: string;
    lname?: string;
    img?: string;
    username?: string;
    password?: string;
    access_key?: string;
    secret_access_key?: string;
}
