import { Component } from '@angular/core';
import { User } from './user';
import { UserService } from './user.service';
import { OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';


@Component({
    selector: 'my-user', //selector for component
    providers: [UserService],
    templateUrl: './user-component.html',
    styleUrls: ['./../assets/css/app.component.css']

})


export class UserComponent implements OnInit {
    constructor(
      private userService: UserService, //inject the UserService
      private http: Http,
      private router: Router) { }


    loggedInUser: User;
    showPassword: boolean = false;
    errorMsg: string;
    errorStatus: number;
    activate_save_credentials = true;
    disable_status: boolean = true;

    //variables to invoke the last pass plugin
    access_key_input_type = "text";
    access_key_input_name = "username";
    access_key_input_id = "username";
    secret_access_key_input_type = "password";
    secret_access_key_input_name = "password";
    secret_access_key_input_id = "password";

    getUser(): void {
         this.userService
             .getUser().subscribe(res => {
                this.loggedInUser = res;
                }, error => {
                    this.errorStatus = error.status;
                    this.errorMsg = error.message;
                });
    }

    ngOnInit(): void {
        this.getUser();
    }

    onRenewCredentials(userName: string): void {
        // Disabling the button in GUI
        this.activate_save_credentials = false;

        this.userService
            .renewUserCredentials().subscribe(res => {
            this.loggedInUser = res;
        }, error =>{
            this.errorMsg = error.message;
        });

    }

    onSaveCredentials(){
        //change the input types to invoke the last pass plugin.
        this.access_key_input_type = "text";
        this.access_key_input_name = "accesskey";
        this.access_key_input_id = "accesskey";

        this.secret_access_key_input_type = "text";
        this.secret_access_key_input_name = "secretkey";
        this.secret_access_key_input_id = "secretkey";
    }

    onShowCredentials() {
        this.access_key_input_type = "text";
        this.secret_access_key_input_type = "text";
        this.disable_status = false;
    }
    onChange(e: Event) {
      //have to explicitly tell TypeScript the type of HTML element as defined here
      //https://developer.mozilla.org/en-US/docs/Web/API
      //if ((<HTMLInputElement>e).checked == true) {
      //  this.showPassword = true;
      //} else {
      //  this.showPassword = false;
      //}
    }
}







