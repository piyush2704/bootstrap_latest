import { User } from './user';

export const UserProfile =
    {
      id:1,
      fname:'Kesha',
      lname:'Williams',
      img:'',
      userName:'kwillz',
      password:'password'
    };
