"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserProfile = {
    id: 1,
    fname: 'Kesha',
    lname: 'Williams',
    img: '',
    userName: 'kwillz',
    password: 'password'
};
//# sourceMappingURL=mock-user.js.map