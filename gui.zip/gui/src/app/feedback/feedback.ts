export class User {
    id?:number;
    ftext?:string;
    access_key?:string;
    secret_access_key?:string;
}