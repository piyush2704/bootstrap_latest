import { Component } from '@angular/core';

import { FeedbackService } from './feedback.service';
import { OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { Observable }        from 'rxjs/Observable';
import {EmailValidator} from "@angular/forms";


@Component({
    selector: 'feedback', //selector for component
    providers: [FeedbackService],
    templateUrl: './feedback-component.html',
    styleUrls: ['./feedback.component.css']
})


export class FeedbackComponent {

    constructor(
        private feedbackService: FeedbackService, //inject the UserService
        private http: Http,
        private router: Router,
        ) { }

}






