"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms"); // <-- NgModel Lives Here
var router_1 = require("@angular/router"); // <-- Handles routing for button clicks and links
var animations_1 = require("@angular/platform-browser/animations"); //<-- Angular Material animation components live here
var http_1 = require("@angular/http"); //<-- Handles Http Requests
var aws_service_1 = require("../app/aws.service");
var material_1 = require("@angular/material"); //<-- Angular Material Components Live Here
var app_component_1 = require("./app.component");
var user_component_1 = require("./user/user.component");
var dashboard_component_1 = require("./dashboard/dashboard.component");
var registration_component_1 = require("./registration/registration.component");
var search_component_1 = require("./search/search.component");
var jwt_token_1 = require("./security/jwt.token");
var feedback_component_1 = require("./feedback/feedback.component");
var fileupload_component_1 = require("./fileupload/fileupload.component");
var ng2_file_upload_1 = require("ng2-file-upload");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [
            platform_browser_1.BrowserModule,
            forms_1.FormsModule,
            forms_1.ReactiveFormsModule,
            http_1.HttpModule,
            animations_1.BrowserAnimationsModule,
            material_1.MatTabsModule,
            material_1.MatRadioModule,
            material_1.MatCardModule,
            material_1.MatButtonModule,
            material_1.MatToolbarModule,
            material_1.MatMenuModule,
            material_1.MatSidenavModule,
            material_1.MatInputModule,
            material_1.MatGridListModule,
            material_1.MatSlideToggleModule,
            material_1.MatSelectModule,
            material_1.MatExpansionModule,
            material_1.MatChipsModule,
            material_1.MatListModule,
            material_1.MatStepperModule,
            // MatIconModule,
            material_1.MatAutocompleteModule,
            /*FileUploadModule,*/
            ng2_file_upload_1.FileUploadModule,
            router_1.RouterModule.forRoot([
                {
                    path: 'user',
                    component: user_component_1.UserComponent
                },
                {
                    path: 'dashboard',
                    component: dashboard_component_1.DashboardComponent
                },
                {
                    path: 'registration',
                    component: registration_component_1.RegistrationComponent
                },
                {
                    path: 'search',
                    component: search_component_1.SearchComponent
                },
                {
                    path: 'feedback',
                    component: feedback_component_1.FeedbackComponent
                },
                {
                    path: 'fileupload',
                    component: fileupload_component_1.FileuploadComponent
                },
                {
                    path: '',
                    redirectTo: '/dashboard',
                    pathMatch: 'full'
                }
            ])
        ],
        declarations: [
            app_component_1.AppComponent,
            user_component_1.UserComponent,
            dashboard_component_1.DashboardComponent,
            registration_component_1.RegistrationComponent,
            search_component_1.SearchComponent,
            feedback_component_1.FeedbackComponent,
            fileupload_component_1.FileuploadComponent
        ],
        providers: [
            aws_service_1.AwsService,
            jwt_token_1.JWTService
        ],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map