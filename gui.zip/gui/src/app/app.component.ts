import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { AwsService } from '../app/aws.service';
import { JWTService } from '../app/security/jwt.token';
import { Subscription } from 'rxjs';

@Component({
    selector: 'my-app',
    templateUrl: './app-component.html',
    styleUrls: ['./assets/css/app.component.css']

})


export class AppComponent implements OnInit {

    constructor(private jwtService: JWTService) { } //inject the UserService

    user:any;
    username:string;
    password:string;
    errorMessage:string;
    redError:string;
    loggedInCreds = {
        accessKey : "",
        secretKey : "",
        sessionToken : "",
        token: ""
    };

    success:string;
    chosenProvider:string;

    ngOnInit(): void {
        console.log("Access Token:", window.location);

        //hash holds the JWT token from Cognito
        var hash = window.location.hash;
        //var oldHash = "#access_token=eyJraWQiOiJ6QTh3K1JcL0xMdjJhS1FBNU92cWtrQmpqZW5pUkloekZRN0RHWjQ5eWlPcz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJhN2NhNTljZS1lMGU1LTQwMmItOWMzMy1lN2Q4NDdkMGU3YjYiLCJ0b2tlbl91c2UiOiJhY2Nlc3MiLCJzY29wZSI6Im9wZW5pZCBlbWFpbCIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX0ZwbjJCTWZrUSIsImV4cCI6MTUwNjA4Nzk3NSwiaWF0IjoxNTA2MDg0Mzc1LCJ2ZXJzaW9uIjoyLCJqdGkiOiI4OWQwN2YzNS01NWQ1LTRjY2UtOTExZC1iNzFmN2EyNTdhNjAiLCJjbGllbnRfaWQiOiI0NzA0cWxpb2k1cm9nYXYwNWJoa2kyZWppdiIsInVzZXJuYW1lIjoiQ0ZBLU9LVEFfN2U1YjgxM2MwNmYwMGE0NDk4YzYwODkwNzAyZTBkYWYifQ.PZEGR4pj3XyjLrjuNy1tF1JEetWGL8adIxLsVcdl5DWddQbDjbKFJ7ulY2OLk0InD0zq4_TpvBohM64tE7JfAunMzV6OZF8Nu-IFRw2w0w8FiasPdv3AgbyUVp0weVigHmuGHkxqYRcaPAumNjIvBRZUIMdrlcaskqsmA_nIfGsZ19jvAJ_zF7U0MXRkdz1ig_7OFArTVRPG5P4c2-d61ZiIuQ-rnylMD8N0YoYPDkH5EX1VRbjjbLBX5NrtqYQX0UvB_QbY8ijKse252ifqigedvg7VigWtmh6DOxkbwqKPgpmHtTybmr_MHkedl09Fj1Xu_lg3AqsprleIhAaUbg&id_token=eyJraWQiOiJnS0pMOTBUOUk5Q2NoR0dlVXo4RXA2djc4OW04N29cL0huUXJlM0RiR0J1VT0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJhN2NhNTljZS1lMGU1LTQwMmItOWMzMy1lN2Q4NDdkMGU3YjYiLCJhdWQiOiI0NzA0cWxpb2k1cm9nYXYwNWJoa2kyZWppdiIsImNvZ25pdG86Z3JvdXBzIjpbInVzLWVhc3QtMV9GcG4yQk1ma1FfQ0ZBLU9LVEEiXSwiaWRlbnRpdGllcyI6W3sidXNlcklkIjoiN2U1YjgxM2MwNmYwMGE0NDk4YzYwODkwNzAyZTBkYWYiLCJwcm92aWRlck5hbWUiOiJDRkEtT0tUQSIsInByb3ZpZGVyVHlwZSI6IlNBTUwiLCJpc3N1ZXIiOiJodHRwOlwvXC93d3cub2t0YS5jb21cL2V4a2JydGhsaG45UUNtRXZPMGg3IiwicHJpbWFyeSI6InRydWUiLCJkYXRlQ3JlYXRlZCI6IjE1MDQyMDAzMjczOTQifV0sInRva2VuX3VzZSI6ImlkIiwiYXV0aF90aW1lIjoxNTA2MDg0Mzc1LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9GcG4yQk1ma1EiLCJjb2duaXRvOnVzZXJuYW1lIjoiQ0ZBLU9LVEFfN2U1YjgxM2MwNmYwMGE0NDk4YzYwODkwNzAyZTBkYWYiLCJleHAiOjE1MDYwODc5NzUsImlhdCI6MTUwNjA4NDM3NX0.jGsDOmyF9ySVPv7cua4m2yEGtDtClN0tQJMFEvqw7tXw4HL5_R5VQELe__yYzM1jny8izPtpSDAEDOC6dWFuzXHy8gLZtxzib492MIlnWIaH87nNhl9EHT5pIQi3iMJokA71tf0RcLePG9n3WyhL6naUuypwz0H1WEMZdAOB77qweKuglnLPj7wCQm-IAB7s4Vo6C_hK7EOJ8oT9v2VIDRAA4cYTTnN-kO1c9q8Fd4sbKkF8I6IJMw_3i8k6GE7lY3wQbbjx7gGxpL8fI9vA5rDxhLYAm-Y0SpXvxS_1ScqzamRJE8LiOSLGXZWOvpRyHmcfSCFrgyaLvQ-n7Mw1DQ&token_type=Bearer&expires_in=3600";
        var hash = "#id_token=eyJraWQiOiJnS0pMOTBUOUk5Q2NoR0dlVXo4RXA2djc4OW04N29cL0huUXJlM0RiR0J1VT0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJhN2NhNTljZS1lMGU1LTQwMmItOWMzMy1lN2Q4NDdkMGU3YjYiLCJhdWQiOiI0NzA0cWxpb2k1cm9nYXYwNWJoa2kyZWppdiIsImNvZ25pdG86Z3JvdXBzIjpbInVzLWVhc3QtMV9GcG4yQk1ma1FfQ0ZBLU9LVEEiXSwiaWRlbnRpdGllcyI6W3sidXNlcklkIjoiN2U1YjgxM2MwNmYwMGE0NDk4YzYwODkwNzAyZTBkYWYiLCJwcm92aWRlck5hbWUiOiJDRkEtT0tUQSIsInByb3ZpZGVyVHlwZSI6IlNBTUwiLCJpc3N1ZXIiOiJodHRwOlwvXC93d3cub2t0YS5jb21cL2V4a2JydGhsaG45UUNtRXZPMGg3IiwicHJpbWFyeSI6InRydWUiLCJkYXRlQ3JlYXRlZCI6IjE1MDQyMDAzMjczOTQifV0sInRva2VuX3VzZSI6ImlkIiwiYXV0aF90aW1lIjoxNTA2MzQ1MTI3LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9GcG4yQk1ma1EiLCJjb2duaXRvOnVzZXJuYW1lIjoiQ0ZBLU9LVEFfN2U1YjgxM2MwNmYwMGE0NDk4YzYwODkwNzAyZTBkYWYiLCJleHAiOjE1MDYzNDg3MjcsImlhdCI6MTUwNjM0NTEyN30.AUf9LsbRW_Q5ZolU7gBYEIataTC2LAAcKtm_YQQvbp1-h5PlkWitx7vopYDheP3FyX5DO1EiRM4pJnRtuvCOE2WmRqfjoZhFlVbTrhkHS8_CS1dlcvsH_vFROKuAw8XlU9RSQZ6c8RnIe1NhRznjmyVLmwLG2xpZ4fBLWkoGoFAZQM0Jbjw_07Yo5wKS6RZBdqT-zK5dUa74Gexz4FnXaVZANQYQ6Bd2G84XF3-xs5k2AkmWdoBl1Q9Zu76s9b1ceQV5YMGfMKJfQsB_pSQUfJCJ3QGZbmrOHFjO2fbzCArlq0XjbexCSZrod7TE6nQI11KshRk_FzWpX3t8YNOFPg&access_token=eyJraWQiOiJ6QTh3K1JcL0xMdjJhS1FBNU92cWtrQmpqZW5pUkloekZRN0RHWjQ5eWlPcz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJhN2NhNTljZS1lMGU1LTQwMmItOWMzMy1lN2Q4NDdkMGU3YjYiLCJ0b2tlbl91c2UiOiJhY2Nlc3MiLCJzY29wZSI6Im9wZW5pZCBlbWFpbCIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX0ZwbjJCTWZrUSIsImV4cCI6MTUwNjM0ODcyNywiaWF0IjoxNTA2MzQ1MTI3LCJ2ZXJzaW9uIjoyLCJqdGkiOiIyMmM3NTM3ZC00MmM4LTRiYmEtODkyNy1hZmJhNWMwYTEzMTUiLCJjbGllbnRfaWQiOiI0NzA0cWxpb2k1cm9nYXYwNWJoa2kyZWppdiIsInVzZXJuYW1lIjoiQ0ZBLU9LVEFfN2U1YjgxM2MwNmYwMGE0NDk4YzYwODkwNzAyZTBkYWYifQ.j3lKb1PrmKk27NB_iKTd4ZFMUbw15qOJ9e6aKf17HqLJjgsXhHW2BQKIWDBUzyq3yoIxWXBNzDAQKTr4mhMQhXMbx6SBxxfPqrvN5zDpMlKIX0s6DWTOEFYeFHuU-fBFDoTyxcG2MENAJfncwqwmdFUZcUnMGs35vRyJTsdbDaLSlQaHQK5Z5yrpc1dlIwwxmqj8O1cMXEPk-7zdM-ZQg0D3aDdNpMM8oKTHra9DULy_36rbNsgvwU62LiBKchZs6nIiZ237jP4CZzR_PQn_cqZnQsloN7NRWO_lkVuirWxM3ySvSrj5MGaE1sG3L9vrSJVbSMIBFFB82Ensct04Lg&expires_in=3600&token_type=Bearer";
        var idToken;
        var accessToken;

        console.log("The hash is: ", hash);

        if (hash) {
            //substring 1 removes the # symbol from the token
            //slot 0 is id_token
            //slot 1 is access_token
            //slot 2 is token_type
            //slot 3 is expires_in
            var elements = hash.substring(1).split('&');

            console.log("Printing out the parsed values");

            for (var item in elements) {
                console.log(elements[item]);
            }

            //get all chars after equal sign
            idToken = elements[0].substring(elements[0].indexOf('=')+1);

            //get all chars after equal sign
            accessToken = elements[1].substring(elements[1].indexOf('=')+1);
        } else {
            window.location.href = 'https://dev.cfahome.com/sso/a/okta';
        }

        this.jwtService.setIdToken(idToken);
        this.jwtService.setAccessToken(accessToken);
    }
}







