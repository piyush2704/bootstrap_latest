"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var dashboard_service_1 = require("./dashboard.service");
var http_1 = require("@angular/http");
var router_1 = require("@angular/router");
var core_2 = require("@angular/core");
var material_1 = require("@angular/material");
require("rxjs/add/operator/startWith");
require("rxjs/add/observable/merge");
require("rxjs/add/operator/map");
var DashboardComponent = (function () {
    // public response:any;
    // search code starts here
    //   public url =
    //       'https://developer.atlassian.com/confdev/confluence-server-rest-api?_ga=2.87646683.278534985.1508338666-18635430.1506355309';
    //   getData() {
    //       this.getWikiRecords(this.url).subscribe(data => {
    //           this.response = data;
    // console.log(this.response);
    // });
    // }
    // getWikiRecords(url: string) {
    //     return this.http.get(url).
    //         map(data => {data.text();
    //         return data.text(); } );
    // }
    function DashboardComponent(dashboardService, //inject the UserService
        http, router) {
        this.dashboardService = dashboardService;
        this.http = http;
        this.router = router;
        this.displayedColumns = ['Name', 'Type', 'Max Length'];
    }
    DashboardComponent.prototype.ngOnInit = function () {
    };
    return DashboardComponent;
}());
__decorate([
    core_2.ViewChild(material_1.MatPaginator),
    __metadata("design:type", material_1.MatPaginator)
], DashboardComponent.prototype, "paginator", void 0);
DashboardComponent = __decorate([
    core_1.Component({
        selector: 'my-dashboard',
        templateUrl: './dashboard-component.html',
        providers: [dashboard_service_1.DashboardService],
        styleUrls: ['./../assets/css/app.component.css']
    }),
    __metadata("design:paramtypes", [dashboard_service_1.DashboardService,
        http_1.Http,
        router_1.Router])
], DashboardComponent);
exports.DashboardComponent = DashboardComponent;
//# sourceMappingURL=dashboard.component.js.map