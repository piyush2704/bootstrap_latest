"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Dashboard = (function () {
    function Dashboard() {
    }
    return Dashboard;
}());
exports.Dashboard = Dashboard;
//# sourceMappingURL=Dashboard.js.map