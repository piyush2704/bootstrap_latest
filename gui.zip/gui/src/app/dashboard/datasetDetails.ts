export class Search {
    results?:string;
}
