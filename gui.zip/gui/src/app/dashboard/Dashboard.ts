export class Dashboard {
    results?:string;
}