"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Search = (function () {
    function Search() {
    }
    return Search;
}());
exports.Search = Search;
//# sourceMappingURL=datasetDetails.js.map