import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { DashboardService } from './dashboard.service';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { Observable }        from 'rxjs/Observable';

import {ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/observable/merge';
import 'rxjs/add/operator/map';

@Component({
    selector: 'my-dashboard', //selector for component
    templateUrl: './dashboard-component.html',
    providers: [DashboardService],
    styleUrls: ['./../assets/css/app.component.css']

})


export class DashboardComponent implements OnInit {

    errorMsg:string;
    errorStatus:number;

    displayedColumns = ['Name', 'Type', 'Max Length'];

    @ViewChild(MatPaginator) paginator:MatPaginator;
    // public response:any;
  // search code starts here
  //   public url =
  //       'https://developer.atlassian.com/confdev/confluence-server-rest-api?_ga=2.87646683.278534985.1508338666-18635430.1506355309';
  //   getData() {
  //       this.getWikiRecords(this.url).subscribe(data => {
  //           this.response = data;
            // console.log(this.response);
        // });
    // }
    // getWikiRecords(url: string) {
    //     return this.http.get(url).
    //         map(data => {data.text();
    //         return data.text(); } );

     // }
    constructor(private dashboardService:DashboardService, //inject the UserService
                private http:Http,
                private router:Router) {
    }

    ngOnInit():void {
    }


}










